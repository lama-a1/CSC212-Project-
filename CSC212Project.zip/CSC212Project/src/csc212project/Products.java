/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

/**
 *
 * @author memem
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Products {
    private LinkedList<Product> productList;

    public Products() {
        productList = new LinkedList<>();
    }

    // Add a product to the list
    public void addProduct(Product product) {
        productList.insertAtEnd(product);
    }

    // Remove product by ID
    public boolean removeProduct(int productId) {
        LinkedList.Node<Product> current = productList.getHead();
        LinkedList.Node<Product> prev = null;
        
        while (current != null) {
            if (current.data.getProductId() == productId) {
                if (prev == null) {
                    productList.head = current.next;
                } else {
                    prev.next = current.next;
                }
                productList.size--;
                return true;
            }
            prev = current;
            current = current.next;
        }
        return false;
    }

    // Update product information
    public boolean updateProduct(int productId, String name, double price, int stock) {
        Product product = searchById(productId);
        if (product != null) {
            product.updateProduct(name, price, stock);
            return true;
        }
        return false;
    }

    // Search for a product by ID
    public Product searchById(int id) {
        LinkedList.Node<Product> current = productList.getHead();
        while (current != null) {
            if (current.data.getProductId() == id)
                return current.data;
            current = current.next;
        }
        return null;
    }

    // Search for products by name
    public LinkedList<Product> searchByName(String name) {
        LinkedList<Product> results = new LinkedList<>();
        LinkedList.Node<Product> current = productList.getHead();
        
        while (current != null) {
            if (current.data.getName().toLowerCase().contains(name.toLowerCase())) {
                results.insertAtEnd(current.data);
            }
            current = current.next;
        }
        return results;
    }

    // Track out of stock products
    public LinkedList<Product> getOutOfStockProducts() {
        LinkedList<Product> outOfStock = new LinkedList<>();
        LinkedList.Node<Product> current = productList.getHead();
        
        while (current != null) {
            if (current.data.isOutOfStock()) {
                outOfStock.insertAtEnd(current.data);
            }
            current = current.next;
        }
        return outOfStock;
    }

    // Display all products
    public void displayAllProducts(boolean showReviews) {
        if (productList.isEmpty()) {
            System.out.println("No products available.");
            return;
        }
        
        LinkedList.Node<Product> current = productList.getHead();
        while (current != null) {
            current.data.displayProduct(showReviews);
            current = current.next;
        }
    }

    public void displayAllProducts() {
        displayAllProducts(false);
    }

    // Load products from dataset file
    public void loadProducts(String filePath) {
        try (Scanner scanner = new Scanner(new File(filePath))) {
            scanner.nextLine(); // Skip header
            int count = 0;
            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                int productId = Integer.parseInt(data[0]);
                String name = data[1];
                double price = Double.parseDouble(data[2]);
                int stock = Integer.parseInt(data[3]);

                Product product = new Product(productId, name, price, stock);
                addProduct(product);
                count++;
            }
            System.out.println(count + " products loaded successfully!");
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
        } catch (Exception e) {
            System.out.println("Error reading products file: " + e.getMessage());
        }
    }

    // Load reviews from dataset file
    public void loadReviews(String filePath) {
        try (Scanner scanner = new Scanner(new File(filePath))) {
            scanner.nextLine(); // Skip header
            int count = 0;
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (!line.isEmpty()) {
                    String[] data = line.split(",", 5);
                    
                    if (data.length >= 5) {
                        String customerId = data[2];
                        int productId = Integer.parseInt(data[1]);
                        int rating = Integer.parseInt(data[3]);
                        String comment = data[4].replace("\"", "");
                    
                        Review review = new Review(customerId, rating, comment);
                        Product product = searchById(productId);

                        if (product != null) {
                            product.addReview(review);
                            count++;
                        }
                    }
                }
            }
            System.out.println(count + " reviews loaded successfully!");
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
        } catch (Exception e) {
            System.out.println("Error reading reviews file: " + e.getMessage());
        }
    }

    // Load all data
    public void loadAllData(String productsFile, String reviewsFile) {
        loadProducts(productsFile);
        loadReviews(reviewsFile);
    }

    public LinkedList<Product> getProductList() {
        return productList;
    }
    
    // 1.Extract reviews from a specific customer
    public LinkedList<Review> getReviewsByCustomer(String customerId) {
        LinkedList<Review> customerReviews = new LinkedList<>();
        LinkedList.Node<Product> currentProduct = productList.getHead();
        
        while (currentProduct != null) {
            Product product = currentProduct.data;
            LinkedList.Node<Review> currentReview = product.getReviews().getHead();
            
            while (currentReview != null) {
                Review review = currentReview.data;
                if (review.getCustomerId().equals(customerId)) {
                    customerReviews.insertAtEnd(review);
                }
                currentReview = currentReview.next;
            }
            currentProduct = currentProduct.next;
        }
        return customerReviews;
    }

    // 2.Suggest "top 3 products" by average rating
    public void displayTop3RatedProducts() {
        if (productList.isEmpty()) {
          System.out.println("No products available.");
          return;
        }
    
        Product first = null, second = null, third = null;
    
        // Find top 3 directly from LinkedList
        LinkedList.Node<Product> current = productList.getHead();
        while (current != null) {
           Product product = current.data;
           double rating = product.getAverageRating();
        
          // Compare with current top 3
         if (first == null || rating > first.getAverageRating()) {
              third = second;
              second = first;
              first = product;
            } else if (second == null || rating > second.getAverageRating()) {
              third = second;
            second = product;
         } else if (third == null || rating > third.getAverageRating()) {
              third = product;
         }
        
            current = current.next;
        }
    
    System.out.println("TOP 3 RATED PRODUCTS:");
    if (first != null) {
        System.out.println("1. " + first.getName() + 
                         " - Rating: " + String.format("%.2f", first.getAverageRating()) + "/5" +
                         " - Price: SR" + first.getPrice());
    }
    if (second != null) {
        System.out.println("2. " + second.getName() + 
                         " - Rating: " + String.format("%.2f", second.getAverageRating()) + "/5" +
                         " - Price: SR" + second.getPrice());
    }
    if (third != null) {
        System.out.println("3. " + third.getName() + 
                         " - Rating: " + String.format("%.2f", third.getAverageRating()) + "/5" +
                         " - Price: SR" + third.getPrice());
    }
}

    // 3.Given two customers IDs, show common products with rating > 4
    public void displayCommonHighlyRatedProducts(String custId1, String custId2) {
        LinkedList<Product> commonProducts = new LinkedList<>();
        LinkedList.Node<Product> current = productList.getHead();
        
        while (current != null) {
            Product product = current.data;
            
            if (product.getAverageRating() > 4.0) {
                boolean cust1Reviewed = false;
                boolean cust2Reviewed = false;
                
                LinkedList.Node<Review> reviewCurrent = product.getReviews().getHead();
                while (reviewCurrent != null) {
                    Review review = reviewCurrent.data;
                    if (review.getCustomerId().equals(custId1)) {
                        cust1Reviewed = true;
                    }
                    if (review.getCustomerId().equals(custId2)) {
                        cust2Reviewed = true;
                    }
                    reviewCurrent = reviewCurrent.next;
                }
                
                if (cust1Reviewed && cust2Reviewed) {
                    commonProducts.insertAtEnd(product);
                }
            }
            current = current.next;
        }
        
        if (commonProducts.isEmpty()) {
            System.out.println("No common highly rated products found.");
        } else {
            System.out.println("Common highly rated products (rating > 4/5) for customers: " + custId1 + " & " + custId2);
            commonProducts.displayAll();
        }
    }
    
    public boolean editReview(int productId, String customerId, int newRating, String newComment) {
        Product product = searchById(productId);
        if (product != null) {
            LinkedList<Review> productReviews = product.getReviews();
            LinkedList.Node<Review> current = productReviews.getHead();
            
            while (current != null) {
                Review review = current.data;
                if (review.getCustomerId().equals(customerId)) {
                    review.setRating(newRating);
                    review.setComment(newComment);
                    return true;
                }
                current = current.next;
            }
        }
        return false;
    }
}