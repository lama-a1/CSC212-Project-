/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

/**
 *
 * @author memem
 */
public class Review {
    private String customerId;
    private int rating;
    private String comment;

    public Review(String customerId, int rating, String comment) {
        this.customerId = customerId;
        
        // Validate rating between 1-5
        if (rating < 1) this.rating = 1;
        else if (rating > 5) this.rating = 5;
        else this.rating = rating;
        
        this.comment = comment;
    }

    // Getters and Setters
    public String getCustomerId() { return customerId; }
    public int getRating() { return rating; }
    public String getComment() { return comment; }

    public void setRating(int rating) {
        if (rating >= 1 && rating <= 5) {
            this.rating = rating;
        }
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    // Display review details
    public void display() {
        System.out.println("Customer: " + customerId + " | Rating: " + rating +"/5"+ " | Comment: " + comment);
    }

    @Override
    public String toString() {
        return " Customer ID: " + customerId + ", Rating: " + rating +"/5"+ ", Comment: " + comment ;
    }
}