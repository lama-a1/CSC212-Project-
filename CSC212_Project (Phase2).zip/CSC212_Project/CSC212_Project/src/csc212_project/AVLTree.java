package csc212_project;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author memem
 */

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class AVLTree<T> {

    private Node root;

    private class Node {
        String key;
        T data;
        Node left, right;
        int height;

        Node(String key, T data) {
            this.key = key;
            this.data = data;
            height = 1;
        }
    }

    public AVLTree() {
        root = null;
    }

    public boolean empty() {
        return root == null;
    }

    private int height(Node n) {
        return n == null ? 0 : n.height;
    }

    private int getBalance(Node n) {
        return n == null ? 0 : height(n.left) - height(n.right);
    }

    private Node rightRotate(Node y) {
        Node x = y.left;
        Node t2 = x.right;

        x.right = y;
        y.left = t2;

        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        return x;
    }

    private Node leftRotate(Node x) {
        Node y = x.right;
        Node t2 = y.left;

        y.left = x;
        x.right = t2;

        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;

        return y;
    }

    
    public void insert(String key, T data) {
        root = insertRec(root, key, data);
    }

    private Node insertRec(Node node, String key, T data) {
        if (node == null)
            return new Node(key, data);

        int cmp = key.compareTo(node.key);

        if (cmp < 0)
            node.left = insertRec(node.left, key, data);
        else if (cmp > 0)
            node.right = insertRec(node.right, key, data);
        else {
            node.data = data;
            return node;
        }

        node.height = Math.max(height(node.left), height(node.right)) + 1;

        int balance = getBalance(node);

       
        if (balance > 1 && key.compareTo(node.left.key) < 0)
            return rightRotate(node);

       
        if (balance < -1 && key.compareTo(node.right.key) > 0)
            return leftRotate(node);

       
        if (balance > 1 && key.compareTo(node.left.key) > 0) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        
        if (balance < -1 && key.compareTo(node.right.key) < 0) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }

    
    public T search(String key) {
        Node n = searchNode(root, key);
        return (n != null) ? n.data : null;
    }

    private Node searchNode(Node node, String key) {
        if (node == null) return null;

        int cmp = key.compareTo(node.key);

        if (cmp == 0) return node;
        if (cmp < 0) return searchNode(node.left, key);
        return searchNode(node.right, key);
    }

   
    public void remove(String key) {
        root = removeRec(root, key);
    }

    private Node removeRec(Node node, String key) {
        if (node == null) return null;

        int cmp = key.compareTo(node.key);

        if (cmp < 0) node.left = removeRec(node.left, key);
        else if (cmp > 0) node.right = removeRec(node.right, key);
        else {
            

            if (node.left == null && node.right == null)
                return null;

            if (node.left == null)
                return node.right;
            if (node.right == null)
                return node.left;

            Node successor = minNode(node.right);
            node.key = successor.key;
            node.data = successor.data;

            node.right = removeRec(node.right, successor.key);
        }

        node.height = Math.max(height(node.left), height(node.right)) + 1;

        int balance = getBalance(node);

        if (balance > 1 && getBalance(node.left) >= 0)
            return rightRotate(node);

        if (balance > 1 && getBalance(node.left) < 0) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        if (balance < -1 && getBalance(node.right) <= 0)
            return leftRotate(node);

        if (balance < -1 && getBalance(node.right) > 0) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }

    private Node minNode(Node node) {
        while (node.left != null)
            node = node.left;
        return node;
    }

   
    public void update(String key, T data) {
        Node node = searchNode(root, key);
        if (node != null) node.data = data;
    }

    public void inOrderTraversal(Consumer<T> action) {
        inOrder(root, action);
    }

    private void inOrder(Node node, Consumer<T> action) {
        if (node != null) {
            inOrder(node.left, action);
            action.accept(node.data);
            inOrder(node.right, action);
        }
    }

    public List<T> getAllElements() {
        List<T> list = new ArrayList<>();
        collect(root, list);
        return list;
    }

    private void collect(Node node, List<T> list) {
        if (node != null) {
            collect(node.left, list);
            list.add(node.data);
            collect(node.right, list);
        }
    }

    public boolean contains(String key) {
        return search(key) != null;
    }
}
