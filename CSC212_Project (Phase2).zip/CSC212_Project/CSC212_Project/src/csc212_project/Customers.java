/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212_project;

/**
 *
 * @author memem
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Customers {
    private int customerId;
    private String name;
    private String email;
    private AVLTree<Orders> ordersTree;

    private static AVLTree<Customers> customersTree = new AVLTree<>();

    public Customers(int customerId, String name, String email) {
        this.customerId = customerId;
        this.name = name;
        this.email = email;
        this.ordersTree = new AVLTree<>();
    }

    public static Customers registerNewCustomer(int id, String name, String email) {
        String key = String.valueOf(id);

        if (customersTree.contains(key)) {
            System.out.println("Customer ID already exists!");
            return null;
        }

        Customers c = new Customers(id, name, email);
        customersTree.insert(key, c);
        System.out.println("Customer registered: " + name + " (ID: " + id + ")");
        return c;
    }

    public static Customers findCustomerById(int id) {
        String key = String.valueOf(id);
        return customersTree.search(key);
    }

    public static void viewOrderHistoryForCustomer(int customerId) {
        Customers c = findCustomerById(customerId);
        if (c == null) {
            System.out.println("Customer with ID " + customerId + " not found.");
            return;
        }
        c.viewOrderHistory();
    }

    public static void loadCustomers(String filePath) {
        File file = new File(filePath);

        try (Scanner sc = new Scanner(file)) {
            if (sc.hasNextLine()) sc.nextLine();

            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split(",", 3);
                if (parts.length < 3) continue;

                int id;
                try {
                    id = Integer.parseInt(parts[0].trim());
                } catch (NumberFormatException e) {
                    continue;
                }

                String name = parts[1].trim();
                String email = parts[2].trim();

                String key = String.valueOf(id);
                if (customersTree.contains(key)) continue;

                Customers c = new Customers(id, name, email);
                customersTree.insert(key, c);
            }

        } catch (FileNotFoundException e) {
            System.out.println("Customers file not found: " + filePath);
        } catch (Exception e) {
            System.out.println("Error reading customers file: " + e.getMessage());
        }
    }

    public void placeOrder(Orders newOrder) {
        if (newOrder == null) {
            System.out.println("Cannot place a null order.");
            return;
        }

        String orderKey = String.valueOf(newOrder.getOrderId());
        ordersTree.insert(orderKey, newOrder);
        System.out.println("Order placed successfully for " + name + " (Order ID: " + newOrder.getOrderId() + ")");
    }

    public void viewOrderHistory() {
        if (ordersTree.empty()) {
            System.out.println(name + " has no orders yet.");
            return;
        }
        System.out.println("Order history for " + name + ":");
        ordersTree.inOrderTraversal(order -> {
            System.out.println("- Order ID: " + order.getOrderId() + ", Status: " + order.getStatus() + ", Total: " + order.getTotalPrice());
        });
    }
    
    public static void searchCustomer(Scanner scanner) {
    System.out.print("Enter Customer ID to search: ");
    int id = scanner.nextInt();
    scanner.nextLine();

    Customers c = findCustomerById(id);

    if (c == null) {
        System.out.println("Customer with ID " + id + " not found.");
    } else {
        System.out.println("Customer found:");
        System.out.println("Name: " + c.getName());
        System.out.println("Email: " + c.getEmail());
        System.out.println("ID: " + c.getCustomerId());
    }
}


    public int getCustomerId() { return customerId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public AVLTree<Orders> getOrdersTree() { return ordersTree; }

    public static AVLTree<Customers> getCustomersTree() {
        return customersTree;
    }

    @Override
    public String toString() {
        return "Customer ID: " + customerId + ", Name: " + name + ", Email: " + email;
    }
}

