package csc212project;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Review {

    // ===================== STATIC LIST FOR ALL REVIEWS =====================
    private static LinkedList<Review> reviewsList = new LinkedList<>();

    private int reviewId;
    private int productId;
    private int customerId;
    private int rating;
    private String comment;

    // ===================== CONSTRUCTOR =====================
    public Review(int reviewId, int productId, int customerId, int rating, String comment) {
        this.reviewId = reviewId;
        this.productId = productId;
        this.customerId = customerId;

        if (rating < 1) this.rating = 1;
        else if (rating > 5) this.rating = 5;
        else this.rating = rating;

        this.comment = (comment == null) ? "" : comment;
    }

    // ===================== GETTERS =====================
    public int getReviewId() { return reviewId; }
    public int getProductId() { return productId; }
    public int getCustomerId() { return customerId; }
    public int getRating() { return rating; }
    public String getComment() { return comment; }

    // ===================== SETTERS =====================
    public void setRating(int rating) {
        if (rating >= 1 && rating <= 5)
            this.rating = rating;
    }

    public void setComment(String comment) {
        this.comment = (comment == null) ? "" : comment;
    }

    // ===================== DISPLAY =====================
    public void display() {
        System.out.println("Customer: " + customerId +
                " | Rating: " + rating + "/5" +
                " | Comment: " + comment);
    }

 @Override
    public String toString() {
        return "Customer ID: " + customerId + ", Rating: " + rating +"/5"+ ", Comment: " + comment;
    }

    
    // =============== STATIC METHODS  ===============

    // ========== ADD REVIEW TO GLOBAL LIST ==========
    public static void addReview(Review r) {
        if (reviewsList.empty()) {
            reviewsList.insert(r);
        } else {
             reviewsList.findFirst();       

        while (!reviewsList.last()) {    
            reviewsList.findNext();
        }
        reviewsList.insert(r); 
        }
    }

    // ========== SEARCH REVIEW BY ID ==========
    public static Review searchReviewById(int reviewId) {
        if (reviewsList.empty()) return null;

        reviewsList.findFirst();
        while (!reviewsList.last()) {
            if (reviewsList.retrieve().getReviewId() == reviewId)
                return reviewsList.retrieve();
            reviewsList.findNext();
        }

        if (reviewsList.retrieve().getReviewId() == reviewId)
            return reviewsList.retrieve();

        return null;
    }

    // ========== GET ALL REVIEWS BELONGING TO A CUSTOMER ==========
    public static LinkedList<Review> getReviewsByCustomer(int customerId) {

    LinkedList<Review> results = new LinkedList<>();
    
    if (reviewsList.empty())
        return results;
   
    reviewsList.findFirst();
    while (true) {
        Review r = reviewsList.retrieve();
        if (r.getCustomerId() == customerId) {
            if (results.empty()) {
                results.insert(r);
            } else {
                results.findFirst();
                while (!results.last()) {
                    results.findNext();
                }
                results.insert(r);  
            }
        }
        if (reviewsList.last()) break;
        reviewsList.findNext();
    }
    return results;
}
    
     // ========== GET COMMON PRODUCTS AVERAGE RATED>4 BETWEEN 2COSTOMERS ==========
   public static void commonProducts(int c1, int c2) {

    LinkedList<Integer> list1 = new LinkedList<>();
    LinkedList<Integer> list2 = new LinkedList<>();
    //list1
    if (!reviewsList.empty()) {
    reviewsList.findFirst();
    while (!reviewsList.last()) {
        Review r = reviewsList.retrieve();

        if (r.getCustomerId() == c1) {
            Product p = Product.searchById(r.getProductId());
            if (p != null && p.getAverageRating() > 4)
                list1.insert(r.getProductId());
        }
        reviewsList.findNext();
    }
    // last element
    Review last = reviewsList.retrieve();
    if (last.getCustomerId() == c1) {
        Product p = Product.searchById(last.getProductId());
        if (p != null && p.getAverageRating() > 4)
            list1.insert(last.getProductId());
    }
}
    //list2
    if (!reviewsList.empty()) {
    reviewsList.findFirst();
    while (!reviewsList.last()) {
        Review r = reviewsList.retrieve();

        if (r.getCustomerId() == c2) {
            Product p = Product.searchById(r.getProductId());
            if (p != null && p.getAverageRating() > 4)
                list2.insert(r.getProductId());
        }
        reviewsList.findNext();
    }
    // last element
    Review last = reviewsList.retrieve();
    if (last.getCustomerId() == c2) {
        Product p = Product.searchById(last.getProductId());
        if (p != null && p.getAverageRating() > 4)
            list2.insert(last.getProductId());
    }
}
    LinkedList<Integer> common = new LinkedList<>();
    if (!list1.empty()) {
        list1.findFirst();
        while (!list1.last()) {
            int pid = list1.retrieve();
            if (list2.search(pid) != null)
                common.insert(pid);
            list1.findNext();
        }
        int pid = list1.retrieve();
        if (list2.search(pid) != null)
            common.insert(pid);
    }

    if (common.empty()) {
        System.out.println("No common products found.");
        return;
    }
    System.out.println("Common highly rated products (rating > 4/5) for customers: "+ c1 + " & " + c2);

    common.findFirst();
    while (!common.last()) {
        int pid = common.retrieve();
        Product p = Product.searchById(pid);
        if (p != null)
            p.displayProduct(false);
        common.findNext();
    }
    int pid = common.retrieve();
    Product p = Product.searchById(pid);
    if (p != null)
        p.displayProduct(false);
}

    // ========== LOAD REVIEWS FROM CSV ==========
    public static void loadReviews(String filePath) {
        try (Scanner scanner = new Scanner(new File(filePath))) {

            scanner.nextLine(); // skip header
            int count = 0;

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) continue;

                String[] data = line.split(",", 5);

                int reviewId = Integer.parseInt(data[0]);
                int productId = Integer.parseInt(data[1]);
                int customerId = Integer.parseInt(data[2]);
                int rating = Integer.parseInt(data[3]);
                String comment = data[4].replace("\"", "");

                Review r = new Review(reviewId, productId, customerId, rating, comment);
                // Add review to global list
                addReview(r);
                // Also attach it to product object
                Product p = Product.searchById(productId);
                if (p != null) {
                    p.addReview(r);
                }
                count++;
            }

            System.out.println(count + " reviews loaded successfully!");

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
        } catch (Exception e) {
            System.out.println("Error reading reviews file: " + e.getMessage());
        }
    }
    
}