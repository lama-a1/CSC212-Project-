package csc212project;

import java.util.Scanner;

public class Main {

    private static final String PRODUCTS_CSV  = "src/csc212project/prodcuts.csv";
    private static final String REVIEWS_CSV   = "src/csc212project/reviews.csv";
    private static final String CUSTOMERS_CSV = "src/csc212project/customers.csv";
    private static final String ORDERS_CSV    = "src/csc212project/orders.csv";

    public static void main(String[] args) {

        // Load all CSV files
        Product.loadProducts(PRODUCTS_CSV);
        Review.loadReviews(REVIEWS_CSV);
        Customers.loadCustomers(CUSTOMERS_CSV);
        Orders.loadOrders(ORDERS_CSV);

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n************************************");
            System.out.println("=== WELCOME TO MANAGEMENT SYSTEM ===");
            System.out.println("************************************");
            System.out.println("1. Products");
            System.out.println("2. Customers");
            System.out.println("3. Orders");
            System.out.println("4. Reviews");
            System.out.println("5. Exit");
            System.out.print("Choose an option (1-5)\nEnter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1: productsMenu(scanner); break;
                case 2: customersMenu(scanner); break;
                case 3: ordersMenu(scanner); break;
                case 4: reviewsMenu(scanner); break;
                case 5: System.out.println("Thank you for using our system!\nGoodbye!"); break;
                default: System.out.println("Invalid choice! Please try again.");
            }

        } while (choice != 5);

        scanner.close();
    }


    // =========================================================================
    //                               PRODUCTS MENU
    // =========================================================================
    public static void productsMenu(Scanner scanner) {
        int choice;
        do {
            System.out.println("\n=== PRODUCT MANAGEMENT ===");
            System.out.println("1. Add new product");
            System.out.println("2. Remove product");
            System.out.println("3. Update product");
            System.out.println("4. Search product by ID");
            System.out.println("5. Search product by Name");
            System.out.println("6. Display all out of stock products");
            System.out.println("7. Return to Main menu");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {

                case 1:
                    addNewProduct(scanner);
                    break;

                case 2:
                    removeProduct(scanner);
                    break;

                case 3:
                    updateProduct(scanner);
                    break;

                case 4:
                    searchProductById(scanner);
                    break;

                case 5:
                    searchProductByName(scanner);
                    break;

                case 6:
                    displayOutOfStock();
                    break;
                    
                case 7:
                    System.out.println("Returning to main menu...");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 7);
    }


    // =========================================================================
    //                              REVIEWS MENU
    // =========================================================================
    public static void reviewsMenu(Scanner scanner) {
        int choice;
        do {
            System.out.println("\n=== REVIEW MANAGEMENT ===");
            System.out.println("1. Add review");
            System.out.println("2. Edit review");
            System.out.println("3. Get average rating for product");
            System.out.println("4. Display Top 3 rated products"); 
            System.out.println("5. Common products (average rating > 4/5) between 2 customers");
            System.out.println("6. Get Reviews by Customer ID");
            System.out.println("7. Return to Main menu");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {

                case 1:
                    addReview(scanner);
                    break;

                case 2:
                    editReview(scanner);
                    break;

                case 3:
                    getAverageRating(scanner);
                    break;

                case 4:
                    Product.displayTop3RatedProducts();
                    break;

                case 5:
                     handleCommonProducts(scanner);
                    break;
                    
                case 6:
                    displayReviewsByCustomer(scanner);
                    break;
                    
                case 7:
                    System.out.println("Returning to main menu...");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 7);
    }


    // =========================================================================
    //                         CUSTOMERS MENU 
    // =========================================================================
    public static void customersMenu(Scanner scanner) {
        int cChoice;
    do {
        System.out.println("\n=== CUSTOMER MANAGEMENT ===");
        System.out.println("1. Register new customer");
        System.out.println("2. Place New Order for specific customer");
        System.out.println("3. View Order history for specific customer");
        System.out.println("4. Return to Main menu");
        System.out.print("Enter your choice: ");

        cChoice = scanner.nextInt();
        scanner.nextLine();

        switch (cChoice) {

            case 1:
                registerCustomer(scanner);
                break;

            case 2:
                placeOrder(scanner);
                break;

            case 3:
                System.out.print("Enter customer ID : ");
                int customerId = scanner.nextInt();
                scanner.nextLine();
                Customers.viewOrderHistoryForCustomer(customerId);
                break;

            case 4:
                System.out.println("Returning to main menu...");
                break;

            default:
                System.out.println("Invalid choice!");
        }

    } while (cChoice != 4);
}


    // =========================================================================
    //                              ORDERS MENU
    // =========================================================================
    public static void ordersMenu(Scanner scanner) {
        int oChoice;
      do {
        System.out.println("\n=== ORDER MANAGEMENT ===");
        System.out.println("1. Place New Order");
        System.out.println("2. Cancel Order");
        System.out.println("3. Update Order (Status)");
        System.out.println("4. Search By ID (linear)");
        System.out.println("5. All orders between two dates");
        System.out.println("6. Return Main menu");
        System.out.print("Enter your choice: ");
                    
        oChoice = scanner.nextInt();
        scanner.nextLine();
        
        switch (oChoice) {

    case 1:
        placeOrder(scanner);
        break;

    case 2:
        cancelOrder(scanner);
        break;

    case 3:
        updateOrderStatus(scanner);
        break;

    case 4:
        searchOrderLinear(scanner);
        break;

    case 5:
        listOrdersBetweenDates(scanner);
        break;

    case 6:
        System.out.println("Returning to main menu...");
        break;

    default:
        System.out.println("Invalid choice! Try again.");
}

    } while (oChoice != 6);       
    }
    


    // =========================================================================
    //                              PRODUCT FUNCTIONS
    // =========================================================================

    public static void addNewProduct(Scanner scanner) {
        System.out.println("\nAdd New Product:");
        System.out.print("Enter Product ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        while (Product.searchById(id) != null) {
            System.out.println("This Product ID already exists. Try again.");
            System.out.print("Enter Product ID: ");
            id = scanner.nextInt();
            scanner.nextLine();
        }

        System.out.print("Enter Product Name: ");
        String name = scanner.nextLine();
        // Check for duplicate name
        while (Product.searchByName(name) != null) {
            System.out.println("This Product Name already exists. Try again.");
            System.out.print("Enter Product Name: ");
            name = scanner.nextLine();
}

        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();

        System.out.print("Enter Stock Quantity: ");
        int stock = scanner.nextInt();

        Product.addProduct(new Product(id, name, price, stock));
        System.out.println("Product added successfully!");
    }


    public static void removeProduct(Scanner scanner) {
        System.out.println("This product will NOT be deleted. Stock will be set to 0.");
        System.out.print("Enter Product ID: ");

        int id = scanner.nextInt();
        Product p = Product.searchById(id);

        if (p == null) {
            System.out.println("Product not found!");
            return;
        }

        Product.updateProduct(id, p.getName(), p.getPrice(), 0);
        System.out.println("Product stock updated successfully.");
    }


    public static void updateProduct(Scanner scanner) {
        System.out.print("Enter Product ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        Product p = Product.searchById(id);

        if (p == null) {
            System.out.println("Product not found!");
            return;
        }

        System.out.println("\n************************************");
        System.out.println("What would you like to update?");
        System.out.println("1. Name");
        System.out.println("2. Price");
        System.out.println("3. Stock");
        System.out.println("4. Update All");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        String name = p.getName();
        double price = p.getPrice();
        int stock = p.getStock();

        switch (choice) {
            case 1:
                System.out.print("Enter new Name: ");
                name = scanner.nextLine();
                break;

            case 2:
                System.out.print("Enter new Price: ");
                price = scanner.nextDouble();
                break;

            case 3:
                System.out.print("Enter new Stock: ");
                stock = scanner.nextInt();
                break;

            case 4:
                System.out.print("Enter new Name: ");
                name = scanner.nextLine();
                System.out.print("Enter new Price: ");
                price = scanner.nextDouble();
                System.out.print("Enter new Stock: ");
                stock = scanner.nextInt();
                break;

            default:
                System.out.println("Invalid choice!");
                return;
        }

        Product.updateProduct(id, name, price, stock);
        System.out.println("Product updated successfully!");
    }


    public static void searchProductById(Scanner scanner) {
        System.out.print("Enter Product ID to search: ");
        int id = scanner.nextInt();

        Product p = Product.searchById(id);

        if (p != null) {
            p.displayProduct(true);
        } else {
            System.out.println("Product with ID " + id + " not found!");
        }
    }
    
    public static void searchProductByName(Scanner scanner) {
    System.out.print("Enter Product Name to search: ");
    String name = scanner.nextLine();

    Product p = Product.searchByName(name);

    if (p != null) {
        p.displayProduct(true);
    } else {
        System.out.println("Product with name \"" + name + "\" not found!");
    }
}



    public static void displayOutOfStock() {
        LinkedList<Product> list = Product.getOutOfStockProducts();

        if (list.empty()) {
            System.out.println("No products out of stock.");
        } else {
            System.out.println("Out of Stock Products:");
            list.displayAll();
        }
    }


    // =========================================================================
    //                              REVIEW FUNCTIONS
    // =========================================================================

    public static void addReview(Scanner scanner) {
        System.out.print("Enter Product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();

        Product product = Product.searchById(productId);

        if (product == null) {
            System.out.println("Product not found!");
            return;
        }

        System.out.print("Enter Review ID: ");
        int reviewId = scanner.nextInt();
        scanner.nextLine();

        while (Review.searchReviewById(reviewId) != null) {
            System.out.println("This Review ID already exists. Try again.");
            System.out.print("Enter Review ID: ");
            reviewId = scanner.nextInt();
            scanner.nextLine();
        }

        System.out.print("Enter Customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();

        while (Customers.findCustomerById(customerId) == null) {
            System.out.println("This Customer ID does NOT exist. Try again.");
            System.out.print("Enter Customer ID: ");
            customerId = scanner.nextInt();
            scanner.nextLine();
        }

        System.out.print("Enter Rating (1-5): ");
        int rating = scanner.nextInt();
        scanner.nextLine();

        while (rating < 1 || rating > 5) {
            System.out.print("Invalid rating! Enter again: ");
            rating = scanner.nextInt();
            scanner.nextLine();
        }

        System.out.print("Enter Comment: ");
        String comment = scanner.nextLine();

        Review r = new Review(reviewId, productId, customerId, rating, comment);
        Review.addReview(r);

        product.addReview(r);

        System.out.println("Review added successfully!");
    }



    public static void editReview(Scanner scanner) {
        System.out.print("Enter Review ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        Review r = Review.searchReviewById(id);

        if (r == null) {
            System.out.println("Review not found!");
            return;
        }

        System.out.println("\n************************************");
        System.out.println("What would you like to update?");
        System.out.println("1. Rating");
        System.out.println("2. Comment");
        System.out.println("3. Update All");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {

            case 1:
                System.out.print("Enter new rating (1-5): ");
                int nr = scanner.nextInt();
                scanner.nextLine();
                while (nr < 1 || nr > 5) {
                    System.out.print("Invalid rating! Enter again: ");
                    nr = scanner.nextInt();
                    scanner.nextLine();
                }
                r.setRating(nr);
                break;

            case 2:
                System.out.print("Enter new comment: ");
                r.setComment(scanner.nextLine());
                break;

            case 3:
                System.out.print("Enter new rating (1-5): ");
                int rr = scanner.nextInt();
                scanner.nextLine();
                while (rr < 1 || rr > 5) {
                    System.out.print("Invalid rating! Enter again: ");
                    rr = scanner.nextInt();
                    scanner.nextLine();
                }
                System.out.print("Enter new comment: ");
                r.setComment(scanner.nextLine());
                r.setRating(rr);
                break;

            default:
                System.out.println("Invalid choice!");
                return;
        }

        System.out.println("Review updated successfully!");
    }



    public static void getAverageRating(Scanner scanner) {
        System.out.print("Enter Product ID: ");
        int id = scanner.nextInt();

        Product p = Product.searchById(id);

        if (p == null) {
            System.out.println("Product not found!");
            return;
        }

        double avg = p.getAverageRating();
        System.out.println("Average rating for " + p.getName() + ": " +
                String.format("%.2f", avg) + "/5");
    }
    
    public static void displayReviewsByCustomer(Scanner scanner) {

    System.out.print("Enter Customer ID: ");
    int cid = scanner.nextInt();
    scanner.nextLine();

    LinkedList<Review> customerReviews = Review.getReviewsByCustomer(cid);

    if (customerReviews.empty()) {
        System.out.println("\nNo reviews found for this customer.\n");
        return;
    }
    System.out.println("\n********** Reviews for Customer " + cid + " **********\n");

    customerReviews.findFirst();
    while (true) {
        Review r = customerReviews.retrieve();

        System.out.println("Product ID : " + r.getProductId());
        System.out.println("Rating     : " + r.getRating());
        System.out.println("Comment    : " + r.getComment());
        System.out.println("-------------------------------------------");
        if (customerReviews.last()) break;
        customerReviews.findNext();
    }
    System.out.println();
}


    public static void handleCommonProducts(Scanner input) {
    System.out.print("Enter first customer ID: ");
    int c1 = input.nextInt();

    System.out.print("Enter second customer ID: ");
    int c2 = input.nextInt();

    // Check if both customers exist
    Customers cust1 = Customers.findCustomerById(c1);
    Customers cust2 = Customers.findCustomerById(c2);

    if (cust1 == null) {
        System.out.println("Customer with ID " + c1 + " not found!");
        return;
    }
    if (cust2 == null) {
        System.out.println("Customer with ID " + c2 + " not found!");
        return;
    }
    Review.commonProducts(c1, c2);
}

    public static void getReviewsByCustomer(Scanner scanner) {
        System.out.print("Enter Customer ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        LinkedList<Review> list = Review.getReviewsByCustomer(id);

        if (list.empty()) {
            System.out.println("No reviews found for customer ID " + id);
        } else {
            System.out.println("Reviews by customer " + id + ":");
            list.displayAll();
        }
    }
    
    // =========================================================================
    //                              CUSTOMERS FUNCTIONS
    // =========================================================================
    public static void registerCustomer(Scanner scanner) {

    System.out.print("Enter customer ID : ");
    int id = scanner.nextInt();
    scanner.nextLine();

    while (Customers.findCustomerById(id) != null) {
        System.out.print("Re-Enter again, ID already available: ");
        id = scanner.nextInt();
        scanner.nextLine();
    }

    System.out.print("Enter customer Name : ");
    String name = scanner.nextLine();

    System.out.print("Enter customer Email : ");
    String email = scanner.nextLine();

    Customers.registerNewCustomer(id, name, email);
    System.out.println("Customer added successfully!");
    System.out.println("************************************");
}

    public static void placeOrder(Scanner scanner) {

    System.out.print("Enter order ID: ");
    int orderId = scanner.nextInt();
    scanner.nextLine();

    while (Orders.searchOrderById(orderId) != null) {
        System.out.print("Re-enter order ID, already exists: ");
        orderId = scanner.nextInt();
        scanner.nextLine();
    }

    System.out.print("Enter customer ID: ");
    int customerId = scanner.nextInt();
    scanner.nextLine();

    Customers customer = Customers.findCustomerById(customerId);
    if (customer == null) {
        System.out.println("Customer not found.");
        return;
    }

    LinkedList<Integer> productIds = new LinkedList<>();
    String cont;

    do {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();

        Product p = Product.searchById(productId);

        if (p == null) {
            System.out.println("No such product ID!");
        } else if (p.getStock() <= 0) {
            System.out.println("Out of stock!");
        } else {
            productIds.insert(productId);
            System.out.println("Product added.");
        }

        System.out.print("Add another product? (Y/N): ");
        cont = scanner.nextLine();

    } while (cont.equalsIgnoreCase("Y"));

    System.out.print("Enter order date (yyyy-MM-dd): ");
    String date = readValidDate(scanner);

    Orders created = Orders.createOrder(orderId, customer, productIds, date, Product.productList);

    if (created != null) {
        System.out.println("Order created successfully!");
    }
}
    // =========================================================================
    //                              ORDERS FUNCTIONS
    // =========================================================================
    public static void cancelOrder(Scanner scanner) {
    System.out.print("Enter Order ID to cancel: ");
    int id = scanner.nextInt();
    scanner.nextLine();

    boolean ok = Orders.cancelOrderById(id);
    if (!ok) {
        System.out.println("Order not found or could not be canceled.");
    }
    }
    public static void updateOrderStatus(Scanner scanner) {
    System.out.print("Enter Order ID to update: ");
    int id = scanner.nextInt();
    scanner.nextLine();

    System.out.print("Enter new status (pending/shipped/delivered/canceled): ");
    String status = scanner.nextLine();

    boolean ok = Orders.updateOrderStatusById(id, status);
    if (!ok) {
        System.out.println("Order not found or invalid status.");
    }
}
    public static void searchOrderLinear(Scanner scanner) {
    System.out.print("Enter Order ID: ");
    int id = scanner.nextInt();
    scanner.nextLine();

    Orders o = Orders.searchOrderById(id);

    if (o == null) {
        System.out.println("Order not found.");
        return;
    }

    System.out.println("Order Found:");
    System.out.println("ID = " + o.getOrderId());
    System.out.println("Customer = " + (o.getCustomer() != null ? o.getCustomer().getName() : "N/A"));
    System.out.println("Date = " + o.getOrderDate());
    System.out.println("Total = " + o.getTotalPrice()+" SR");
    System.out.println("Status = " + o.getStatus());
}
    public static void listOrdersBetweenDates(Scanner scanner) {
    System.out.print("Enter start date (yyyy-MM-dd): ");
    String start = readValidDate(scanner);

    System.out.print("Enter end date (yyyy-MM-dd): ");
    String end = readValidDate(scanner);

    Orders.printOrdersBetweenDates(start, end);
}

private static String readValidDate(Scanner scanner) {
    while (true) {
        System.out.print("Enter order date (yyyy-MM-dd): ");
        String date = scanner.nextLine().trim();

        if (date.matches("\\d{4}-\\d{2}-\\d{2}")) {
            return date;
        }

        System.out.println("Invalid date format! Please enter in yyyy-MM-dd format.");
    }
}



}
