package csc212project;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Product {

    // ===================== STATIC LIST FOR ALL PRODUCTS =====================
    public static LinkedList<Product> productList = new LinkedList<>();

    private int productId;
    private String name;
    private double price;
    private int stock;
    private LinkedList<Review> reviews;

    // ===================== CONSTRUCTOR =====================
    public Product(int productId, String name, double price, int stock) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.reviews = new LinkedList<>();
    }

    // ===================== GETTERS =====================
    public int getProductId() { return productId; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getStock() { return stock; }
    public LinkedList<Review> getReviews() { return reviews; }

    // ===================== UPDATE PRODUCT =====================
    public void updateProduct(String name, double price, int stock) {
        this.name = name;
        this.price = price;
        this.stock = stock;
    }


    // ===================== ADD REVIEW TO PRODUCT =====================
    public void addReview(Review review) {
        if (reviews.empty()) {
            reviews.insert(review);
        } else {
            reviews.findFirst();        

        while (!reviews.last()) {        
            reviews.findNext();
        }
        reviews.insert(review);  
        }
    }

    // ===================== DISPLAY PRODUCT =====================
    public void displayProduct(boolean showReviews) {
        System.out.println("Product ID: " + productId +
                ", Name: " + name +
                ", Price: " + price +
                ", Stock: " + stock);

        if (showReviews) {
            if (reviews.empty()) {
                System.out.println("   No reviews yet.");
            } else {
                System.out.println("   Reviews:");
                reviews.displayAll();
            }
        }
    }

    // ===================== CALCULATE AVERAGE RATING =====================
    public double getAverageRating() {
        if (reviews.empty()) return 0.0;

        double total = 0;
        int count = 0;

        reviews.findFirst();
        while (!reviews.last()) {
            total += reviews.retrieve().getRating();
            count++;
            reviews.findNext();
        }

        total += reviews.retrieve().getRating();
        count++;

        return total / count;
    }
    
    // Stock management
    public void decreaseStock(int quantity) { 
        if (this.stock >= quantity) 
        { this.stock -= quantity; } 
    } 
    public void increaseStock(int quantity) { 
        this.stock += quantity; 
    } 
    public boolean isOutOfStock() { 
        return stock == 0; 
    }
    
    @Override
    public String toString() {
        return "Product ID: " + productId + ", Name: " + name + ", Price: " + price + " SR"+ ", Stock: " + stock +"\n";
    }

    // =====================================================================
    // ===================== STATIC METHODS FROM OLD Products.java =========
    // =====================================================================

    // ========== ADD PRODUCT ==========
    public static void addProduct(Product product) {
        if (productList.empty()) {
            productList.insert(product);
        } else {
            productList.findFirst();        

        while (!productList.last()) {   
            productList.findNext();
        }
        productList.insert(product);   
        }
    }

    // ========== SEARCH BY ID ==========
    public static Product searchById(int id) {
        if (productList.empty()) return null;

        productList.findFirst();
        while (!productList.last()) {
            if (productList.retrieve().getProductId() == id)
                return productList.retrieve();
            productList.findNext();
        }

        if (productList.retrieve().getProductId() == id)
            return productList.retrieve();

        return null;
    }
    
    // ========== SEARCH BY Name ==========
    public static Product searchByName(String name) {

    if (productList.empty()) 
        return null;

    productList.findFirst();
    while (!productList.last()) {
        if (productList.retrieve().getName().equalsIgnoreCase(name)) 
            return productList.retrieve();

        productList.findNext();
    }

    if (productList.retrieve().getName().equalsIgnoreCase(name))
        return productList.retrieve();

    return null;
}



    // ========== UPDATE PRODUCT ==========
    public static boolean updateProduct(int productId, String name, double price, int stock) {
        Product p = searchById(productId);
        if (p == null) return false;

        p.updateProduct(name, price, stock);
        return true;
    }
    
    

    // ========== LOAD PRODUCTS ==========
    public static void loadProducts(String filePath) {
        try (Scanner scanner = new Scanner(new File(filePath))) {

            scanner.nextLine(); // Skip header
            int count = 0;

            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                int productId = Integer.parseInt(data[0]);
                String name = data[1];
                double price = Double.parseDouble(data[2]);
                int stock = Integer.parseInt(data[3]);

                Product product = new Product(productId, name, price, stock);
                addProduct(product);
                count++;
            }
            System.out.println(count + " products loaded successfully!");

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
        } catch (Exception e) {
            System.out.println("Error reading products file: " + e.getMessage());
        }
    }

    // ========== DISPLAY ALL PRODUCTS ==========
    public static void displayAllProducts(boolean showReviews) {
        if (productList.empty()) {
            System.out.println("No products available.");
            return;
        }

        productList.findFirst();
        while (!productList.last()) {
            productList.retrieve().displayProduct(showReviews);
            productList.findNext();
        }

        productList.retrieve().displayProduct(showReviews);
    }

    public static void displayAllProducts() {
        displayAllProducts(false);
    }

    // ========== OUT OF STOCK LIST ==========
    public static LinkedList<Product> getOutOfStockProducts() {
        LinkedList<Product> out = new LinkedList<>();

        if (productList.empty()) return out;

        productList.findFirst();
        while (!productList.last()) {
            Product p = productList.retrieve();
            if (p.isOutOfStock()) out.insert(p);
            productList.findNext();
        }

        Product last = productList.retrieve();
        if (last.isOutOfStock()) out.insert(last);

        return out;
    }

    // ========== TOP 3 RATED PRODUCTS ==========
    public static void displayTop3RatedProducts() {
        if (productList.empty()) {
            System.out.println("No products available.");
            return;
        }

        Product first = null, second = null, third = null;

        productList.findFirst();
        while (!productList.last()) {
            Product p = productList.retrieve();
            double r = p.getAverageRating();

            if (first == null || r > first.getAverageRating()) {
                third = second;
                second = first;
                first = p;
            } else if (second == null || r > second.getAverageRating()) {
                third = second;
                second = p;
            } else if (third == null || r > third.getAverageRating()) {
                third = p;
            }

            productList.findNext();
        }

        Product last = productList.retrieve();
        double r = last.getAverageRating();
        if (first == null || r > first.getAverageRating()) {
            third = second;
            second = first;
            first = last;
        } else if (second == null || r > second.getAverageRating()) {
            third = second;
            second = last;
        } else if (third == null || r > third.getAverageRating()) {
            third = last;
        }

        System.out.println("TOP 3 RATED PRODUCTS:");
        if (first != null)
            System.out.println("1. " + first.getName() + " | Rating: " +
                    String.format("%.2f", first.getAverageRating()) +
                    "/5 , Price: " + first.getPrice() + " SR");

        if (second != null)
            System.out.println("2. " + second.getName() + " | Rating: " +
                    String.format("%.2f", second.getAverageRating()) +
                    "/5 , Price: " + second.getPrice() + " SR");

        if (third != null)
            System.out.println("3. " + third.getName() + " | Rating: " +
                    String.format("%.2f", third.getAverageRating()) +
                    "/5 , Price: " + third.getPrice() + " SR");
    }
    
}

