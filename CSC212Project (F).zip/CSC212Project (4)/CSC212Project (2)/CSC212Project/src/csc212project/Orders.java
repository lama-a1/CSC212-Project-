/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author waada
 */
public class Orders {

    // ===== Attributes =====
    private int orderId;
    private Customers customer;
    private LinkedList<Integer> products; // product IDs
    private double totalPrice;
    private String orderDate;
    private String status; // pending, shipped, delivered, canceled

    // ===== GLOBAL LIST =====
    private static LinkedList<Orders> ordersList = new LinkedList<>();

    // ===== Constructors =====
    public Orders(int orderId, Customers customer, double totalPrice, String orderDate, String status) {
        this.orderId = orderId;
        this.customer = customer;
        this.products = new LinkedList<>();
        this.totalPrice = totalPrice;
        this.orderDate = orderDate;
        this.status = normalizeStatus(status);
    }

    public Orders(int orderId, Customers customer, LinkedList<Integer> products,
                  String orderDate, String status) {
        this.orderId = orderId;
        this.customer = customer;
        this.products = (products != null ? products : new LinkedList<>());
        this.totalPrice = 0.0;
        this.orderDate = orderDate;
        this.status = normalizeStatus(status);
    }

    // =========================== CREATE ORDER ===========================
    public static Orders createOrder(int orderId,
                                     Customers customer,
                                     LinkedList<Integer> productIds,
                                     String orderDate,
                                     LinkedList<Product> productsList) {

        if (ordersList.full()) {
            System.out.println("Cannot create order. List is full!");
            return null;
        }

        if (customer == null) {
            System.out.println("Cannot create order without a customer!");
            return null;
        }

        Orders o = new Orders(orderId, customer, productIds, orderDate, "pending");

        if (!o.computeAndReserve(productsList)) {
            System.out.println("Order creation failed due to stock issues.");
            return null;
        }

        // insert into global list
        if (ordersList.empty()) ordersList.insert(o);
        else {
            ordersList.findFirst();
            while (!ordersList.last()) ordersList.findNext();
            ordersList.insert(o);
        }

        customer.placeOrder(o);

        System.out.println("Order created (ID: " + orderId + ") for " + customer.getName() +
                           " | Total price: " + o.totalPrice);
        return o;
    }

    // =========================== CANCEL ORDER ===========================
    public static boolean cancelOrderById(int targetId) {
        Orders o = searchOrderById(targetId);
        if (o == null) return false;

        o.cancel();
        System.out.println("Order " + targetId + " has been canceled.");
        return true;
    }

    // =========================== UPDATE STATUS ===========================
    public static boolean updateOrderStatusById(int targetId, String newStatus) {
        if (!isValidStatus(newStatus) || ordersList.empty()) return false;

        ordersList.findFirst();
        while (true) {
            Orders o = ordersList.retrieve();
            if (o.orderId == targetId) {
                o.status = normalizeStatus(newStatus);
                ordersList.update(o);
                System.out.println("Order " + targetId + " status updated to: " + o.status);
                return true;
            }
            if (ordersList.last()) break;
            ordersList.findNext();
        }

        return false;
    }

    // =========================== SEARCH ORDER ===========================
    public static Orders searchOrderById(int targetId) {
        if (ordersList.empty()) return null;

        ordersList.findFirst();
        while (true) {
            Orders o = ordersList.retrieve();
            if (o.orderId == targetId) return o;

            if (ordersList.last()) break;
            ordersList.findNext();
        }

        return null;
    }

    // =========================== PRINT BETWEEN DATES ===========================
    public static void printOrdersBetweenDates(String start, String end) {
        if (ordersList.empty()) {
            System.out.println("There are no orders in the system.");
            return;
        }

        boolean found = false;
        ordersList.findFirst();

        while (true) {
            Orders o = ordersList.retrieve();
            if (o.orderDate.compareTo(start) >= 0 && o.orderDate.compareTo(end) <= 0) {

                if (!found) {
                    System.out.println("Orders between " + start + " and " + end + ":");
                    found = true;
                }

                System.out.println("ID=" + o.orderId +
                                   ", Customer=" + o.customer.getName() +
                                   ", Date=" + o.orderDate +
                                   ", Total=" + o.totalPrice +
                                   ", Status=" + o.status);
            }

            if (ordersList.last()) break;
            ordersList.findNext();
        }

        if (!found) System.out.println("No orders found in this date range.");
    }

    // =========================== LOAD ORDERS ===========================
    public static void loadOrders(String filePath) {

        File file = new File(filePath);
        int count = 0;

        try (Scanner sc = new Scanner(file)) {

            if (sc.hasNextLine()) sc.nextLine();

            while (sc.hasNextLine()) {

                String[] parts = sc.nextLine().trim().split(",");
                if (parts.length < 3) continue;

                int orderId = Integer.parseInt(parts[0].trim());
                if (searchOrderById(orderId) != null) continue;

                int customerId = Integer.parseInt(parts[1].trim());
                Customers cust = Customers.findCustomerById(customerId);

                String productIdsStr = parts[2].trim();
                double total = Double.parseDouble(parts[3].trim());
                String date = parts[4].trim();
                String status = (parts.length > 5 ? parts[5].trim() : "pending");


                Orders o = new Orders(orderId, cust, total, date, status);

                if (ordersList.empty()) ordersList.insert(o);
                else {
                    ordersList.findFirst();
                    while (!ordersList.last()) ordersList.findNext();
                    ordersList.insert(o);
                }

                if (cust != null) {
                    LinkedList<Orders> custOrders = cust.getOrders();
                    if (custOrders.empty()) custOrders.insert(o);
                    else {
                        custOrders.findFirst();
                        while (!custOrders.last()) custOrders.findNext();
                        custOrders.insert(o);
                    }
                }

                count++;
            }

            System.out.println(count + " orders loaded successfully!");

        } catch (Exception e) {
            System.out.println("Error loading orders: " + e.getMessage());
        }
    }

    // =========================== COMPUTE & RESERVE ===========================
    public boolean computeAndReserve(LinkedList<Product> productsList) {

        if (productsList == null || products.empty())
            return false;

        double total = 0.0;

        products.findFirst();
        while (true) {

            Integer productId = products.retrieve();
            Product found = null;

            // ابحث في productsList
            productsList.findFirst();
            while (true) {
                Product temp = productsList.retrieve();
                if (temp.getProductId() == productId) {
                    found = temp;
                    break;
                }
                if (productsList.last()) break;
                productsList.findNext();
            }

            if (found == null) {
                System.out.println("Product ID " + productId + " not found!");
                return false;
            }

            if (found.getStock() <= 0) {
                System.out.println("Out of stock: " + found.getName());
                return false;
            }

            total += found.getPrice();
            found.decreaseStock(1);

            if (products.last()) break;
            products.findNext();
        }

        this.totalPrice = total;
        return true;
    }

    // =========================== CANCEL INSTANCE ===========================
    public void cancel() {
        this.status = "canceled";
    }

    // =========================== STATUS HELPERS ===========================
    private static boolean isValidStatus(String s) {
        if (s == null) return false;
        String st = s.toLowerCase();
        return st.equals("pending") || st.equals("shipped")
                || st.equals("delivered") || st.equals("canceled");
    }

    private static String normalizeStatus(String s) {
        return (s == null) ? "pending" : s.toLowerCase();
    }

    // =========================== GETTERS ===========================
    public int getOrderId() { return orderId; }
    public Customers getCustomer() { return customer; }
    public LinkedList<Integer> getProducts() { return products; }
    public double getTotalPrice() { return totalPrice; }
    public String getOrderDate() { return orderDate; }
    public String getStatus() { return status; }

    public static LinkedList<Orders> getOrdersList() { return ordersList; }
    
    public void setCustomer(Customers c) {
    this.customer = c;
}

}
