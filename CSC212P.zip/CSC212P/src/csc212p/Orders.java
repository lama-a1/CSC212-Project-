/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212p;

/**
 *
 * @author waada
 */
public class Orders {
    private int orderId;
    private Customers customer;
    // private LinkedList<Integer> products;
    private double totalPrice;
    private String orderDate;
    private String status; // pending, shipped, delivered, canceled

    public Orders(int orderId, Customers customer, double totalPrice, String orderDate, String status) {
        this.orderId   = orderId;
        this.customer  = customer;
        this.totalPrice = totalPrice;
        this.orderDate  = orderDate;
        this.status     = status;
    }

    public static Orders createOrder(LinkedList<Orders> list,
                                     int orderId,
                                     Customers customer,
                                     double totalPrice,
                                     String orderDate) {
        if (list.full()) {
            System.out.println("Cannot create order. Orders list is full!");
            return null;
        }
        Orders o = new Orders(orderId, customer, totalPrice, orderDate, "pending");

        if (list.empty()) {
            list.insert(o);
        } else {
            list.findfirst();
            while (!list.last()) list.findnext();
            list.insert(o);
        }
        System.out.println("Order created (ID: " + orderId + ") for customer: " +
                (customer != null ? customer.getName() : "N/A"));
        return o;
    }

    public void cancel() { this.status = "canceled"; }

    public boolean updateStatus(String newStatus) {
        if (!isValidStatus(newStatus)) {
            System.out.println("Invalid status: " + newStatus);
            return false;
        }
        this.status = newStatus;
        return true;
    }

    public static Orders searchOrderById(LinkedList<Orders> list, int targetId) {
        if (list == null || list.empty()) return null;
        list.findfirst();
        while (true) {
            Orders cur = list.retrieve();
            if (cur != null && cur.orderId == targetId) return cur;
            if (list.last()) break;
            list.findnext();
        }
        return null;
    }

    public static boolean updateOrderStatusById(LinkedList<Orders> list, int targetId, String newStatus) {
        if (!isValidStatus(newStatus) || list == null || list.empty()) return false;
        list.findfirst();
        while (true) {
            Orders cur = list.retrieve();
            if (cur != null && cur.orderId == targetId) {
                cur.status = newStatus;
                list.update(cur);
                return true;
            }
            if (list.last()) break;
            list.findnext();
        }
        return false;
    }

    private static boolean isValidStatus(String s) {
        return "pending".equals(s) || "shipped".equals(s) || "delivered".equals(s) || "canceled".equals(s);
    }

    public int getOrderId()       { return orderId; }
    public double getTotalPrice() { return totalPrice; }
    public String getStatus()     { return status; }
    public String getOrderDate()  { return orderDate; }
    public Customers getCustomer(){ return customer; }
    public void setOrderDate(String orderDate){ this.orderDate = orderDate; }
    public void setCustomer(Customers customer){ this.customer = customer; }
    public void setTotalPrice(double totalPrice){ this.totalPrice = totalPrice; }
}

