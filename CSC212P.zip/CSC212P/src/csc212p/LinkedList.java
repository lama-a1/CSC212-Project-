/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212p;

/**
 *
 * @author waada
 */
public class LinkedList<T> {

    // ===== Node class =====
    private class Node<E> {
        E data;
        Node<E> next;

        Node(E val) {
            data = val;
            next = null;
        }
    }

    // ===== Attributes =====
    private Node<T> head;
    private Node<T> current;

    
    public LinkedList() {
        head = current = null;
    }

    
    public boolean empty() {
        return head == null;
    }

    
    public boolean full() {
        return false;
    }

    
    public void findfirst() {
        current = head;
    }

   
    public void findnext() {
        current = current.next;
    }

    
    public boolean last() {
        return current.next == null;
    }

    
    public T retrieve() {
        return current.data;
    }

    
    public void update(T val) {
        current.data = val;
    }

    
    public void insert(T val) {
        Node<T> tmp;

        if (empty()) {
            head = new Node<T>(val);
            current = head;
        } else {
            tmp = current.next;
            current.next = new Node<T>(val);
            current = current.next;
            current.next = tmp;
        }
    }

    
    public void remove() {
        if (current == head) {
            head = head.next;
        } else {
            Node<T> tmp = head;
            while (tmp.next != current)
                tmp = tmp.next;
            tmp.next = current.next;
        }

        if (current.next == null)
            current = head;
        else
            current = current.next;
    }
}


