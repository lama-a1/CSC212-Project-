/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

/**
 *
 * @author memem
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
public class LinkedList<T> {
    public static class Node<T> {
        public T data;
        public Node<T> next;

        public Node(T data) {
            this.data = data;
            this.next = null;
        }
    }

    public Node<T> head;
    public int size;
    private Node<T> current;

    public LinkedList() {
        head = null;
        size = 0;
    }

    public boolean empty() { return head == null; }
    public Node<T> getHead() { return head; }
    public int size() { return size; }

     public void findFirst() {
        current = head;
    }

   
    public void findNext() {
        current = current.next;
    }

    
    public boolean last() {
        return current.next == null;
    }

    
    public T retrieve() {
        return current.data;
    }

    
    public void update(T val) {
        current.data = val;
    }

    
    public void insert(T val) {
        Node<T> tmp;

        if (empty()) {
            head = new Node<T>(val);
            current = head;
        } else {
            tmp = current.next;
            current.next = new Node<T>(val);
            current = current.next;
            current.next = tmp;
        }
    }

    
    public void remove() {
        if (current == head) {
            head = head.next;
        } else {
            Node<T> tmp = head;
            while (tmp.next != current)
                tmp = tmp.next;
            tmp.next = current.next;
        }

        if (current.next == null)
            current = head;
        else
            current = current.next;
    } 
    
    // Insert element at the end
    public void insertAtEnd(T data) {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
        } else {
            Node<T> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        size++;
    }

    // Insert element at the beginning
    public void insertAtBeginning(T data) {
        Node<T> newNode = new Node<>(data);
        newNode.next = head;
        head = newNode;
        size++;
    }

    // Remove element
    public boolean remove(T target) {
        if (head == null) return false;
        
        if (head.data.equals(target)) {
            head = head.next;
            size--;
            return true;
        }
        
        Node<T> current = head;
        while (current.next != null) {
            if (current.next.data.equals(target)) {
                current.next = current.next.next;
                size--;
                return true;
            }
            current = current.next;
        }
        return false;
    }

    // Search for element
    public Node<T> search(T target) {
        Node<T> current = head;
        while (current != null) {
            if (current.data.equals(target)) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

    // Get element at index
    public T get(int index) {
        if (index < 0 || index >= size) return null;
        
        Node<T> current = head;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        return current.data;
    }

    // Display all elements
    public void displayAll() {
        if (empty()) {
            System.out.println("List is empty");
            return;
        }
        
        Node<T> current = head;
        int index = 1;
        while (current != null) {
            System.out.println(index + ". " + current.data.toString());
            current = current.next;
            index++;
        }
    }
    public boolean full() {
        return false;
    }

    
   
}
