/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

/**
 *
 * @author waada
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author waada
 */


public class Orders {

    private int orderId;
    private Customers customer;
    private LinkedList<Integer> products; // store product IDs
    private double totalPrice;
    private String orderDate;
    private String status; // pending, shipped, delivered, canceled

  
    public Orders(int orderId, Customers customer, double totalPrice, String orderDate, String status) {
        this.orderId = orderId;
        this.customer = customer;
        this.products = new LinkedList<>();
        this.totalPrice = totalPrice;
        this.orderDate = orderDate;
        this.status = normalizeStatus(status);
    }

    public Orders(int orderId, Customers customer, LinkedList<Integer> products,
                  String orderDate, String status) {
        this.orderId = orderId;
        this.customer = customer;
        this.products = (products != null ? products : new LinkedList<>());
        this.totalPrice = 0.0;
        this.orderDate = orderDate;
        this.status = normalizeStatus(status);
    }

    // -------- Create Order --------
    
    public static Orders createOrder(LinkedList<Orders> orderList,
                                     int orderId,
                                     Customers customer,
                                     double totalPrice,
                                     String orderDate) {
        if (orderList.full()) {
            System.out.println("Cannot create order. List is full!");
            return null;
        }

        Orders o = new Orders(orderId, customer, totalPrice, orderDate, "pending");

        if (orderList.empty()) orderList.insert(o);
        else {
            orderList.findFirst();
            while (!orderList.last()) orderList.findNext();
            orderList.insert(o);
        }

        if (customer != null) customer.placeOrder(o);

        System.out.println("Order created (ID: " + orderId + ") for customer: " +
                (customer != null ? customer.getName() : "N/A"));
        return o;
    }

    
    public static Orders createOrder(LinkedList<Orders> orderList,
                                     int orderId,
                                     Customers customer,
                                     LinkedList<Integer> productIds,
                                     String orderDate,
                                     Products productsData) {
        if (orderList.full()) {
            System.out.println("Cannot create order. List is full!");
            return null;
        }
        if (customer == null) {
            System.out.println("Cannot create order without a customer!");
            return null;
        }

        Orders o = new Orders(orderId, customer, productIds, orderDate, "pending");

        if (!o.computeAndReserve(productsData)) {
            System.out.println("Order creation failed due to stock issues.");
            return null;
        }

        if (orderList.empty()) orderList.insert(o);
        else {
            orderList.findFirst();
            while (!orderList.last()) orderList.findNext();
            orderList.insert(o);
        }

        customer.placeOrder(o);

        System.out.println("Order created (ID: " + orderId + ") for " + customer.getName() +
                           " | Total: " + o.getTotalPrice());
        return o;
    }

   
    public boolean computeAndReserve(Products productsData) {
        if (productsData == null || products.empty()) return false;

        double total = 0.0;
        products.findFirst();
        while (true) {
            Integer productId = products.retrieve();
            Product p = productsData.searchById(productId);
            if (p == null) {
                System.out.println("Product ID " + productId + " not found!");
                return false;
            }
            if (p.getStock() <= 0) {
                System.out.println("Out of stock for product: " + p.getName());
                return false;
            }

            total += p.getPrice();
            p.decreaseStock(1); 

            if (products.last()) break;
            products.findNext();
        }
        this.totalPrice = total;
        return true;
    }

    
    public void cancel() {
        this.status = "canceled";
    }

    public boolean updateStatus(String newStatus) {
        if (!isValidStatus(newStatus)) {
            System.out.println("Invalid status: " + newStatus);
            return false;
        }
        this.status = normalizeStatus(newStatus);
        return true;
    }

    // -------- Search / Update --------
    public static Orders searchOrderById(LinkedList<Orders> list, int targetId) {
        if (list == null || list.empty()) return null;
        list.findFirst();
        while (true) {
            Orders o = list.retrieve();
            if (o != null && o.orderId == targetId) return o;
            if (list.last()) break;
            list.findNext();
        }
        return null;
    }

    public static boolean updateOrderStatusById(LinkedList<Orders> list, int targetId, String newStatus) {
        if (!isValidStatus(newStatus) || list == null || list.empty()) return false;
        list.findFirst();
        while (true) {
            Orders o = list.retrieve();
            if (o != null && o.orderId == targetId) {
                o.status = normalizeStatus(newStatus);
                list.update(o);
                return true;
            }
            if (list.last()) break;
            list.findNext();
        }
        return false;
    }

   
    private static boolean isValidStatus(String s) {
        if (s == null) return false;
        String st = s.toLowerCase();
        return st.equals("pending") || st.equals("shipped") || st.equals("delivered") || st.equals("canceled");
    }

    private static String normalizeStatus(String s) {
        return (s == null) ? "pending" : s.toLowerCase();
    }

    // -------- Getters / Setters --------
    public int getOrderId() { return orderId; }
    public Customers getCustomer() { return customer; }
    public LinkedList<Integer> getProducts() { return products; }
    public double getTotalPrice() { return totalPrice; }
    public String getOrderDate() { return orderDate; }
    public String getStatus() { return status; }

    public void setCustomer(Customers customer) { this.customer = customer; }
    public void setOrderDate(String orderDate) { this.orderDate = orderDate; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
}
