/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

/**
 *
 * @author waada
 */


public class Customers {

    private int customerId;
    private String name;
    private String email;
    private LinkedList<Orders> orders;

    public Customers(int customerId, String name, String email) {
        this.customerId = customerId;
        this.name = name;
        this.email = email;
        this.orders = new LinkedList<>();
    }

    public static Customers registerCustomer(int id, String name, String email) {
        return new Customers(id, name, email);
    }

 
    public void placeOrder(Orders newOrder) {
        if (newOrder == null) {
            System.out.println("Cannot place a null order.");
            return;
        }
        if (newOrder.getCustomer() != this) {
            newOrder.setCustomer(this);
        }

        if (orders.full()) {
            System.out.println("Cannot place order. Orders list is full!");
            return;
        }

        if (orders.empty()) orders.insert(newOrder);
        else {
            orders.findFirst();
            while (!orders.last()) orders.findNext();
            orders.insert(newOrder);
        }

        System.out.println("Order placed successfully for " + name + 
                           " (Order ID: " + newOrder.getOrderId() + ")");
    }

    /** Display all orders made by this customer. */
    public void viewOrderHistory() {
        if (orders.empty()) {
            System.out.println(name + " has no orders yet.");
            return;
        }
        System.out.println("Order history for " + name + ":");
        orders.findFirst();
        while (true) {
            Orders o = orders.retrieve();
            if (o != null) {
                System.out.println("- Order ID: " + o.getOrderId() +
                                   ", Status: " + o.getStatus() +
                                   ", Total: " + o.getTotalPrice());
            }
            if (orders.last()) break;
            orders.findNext();
        }
    }

    // Getters
    public int getCustomerId() { return customerId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public LinkedList<Orders> getOrders() { return orders; }
}


