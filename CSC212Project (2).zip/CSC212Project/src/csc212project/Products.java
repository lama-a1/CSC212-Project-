/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

/**
 *
 * @author memem
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Products {
    private LinkedList<Product> productList;

    public Products() {
        productList = new LinkedList<>();
    }

    // Add a product to the list
    public void addProduct(Product product) {
        if (productList.empty()) {
            productList.insert(product);
        } else {
            productList.findFirst();
            while (!productList.last()) {
                productList.findNext();
            }
            productList.insert(product);
        }
    }

    // Remove product by ID
    public boolean removeProduct(int productId) {
        if (productList.empty()) {
            return false;
        }
        
        // Search for the product to remove
        productList.findFirst();
        while (!productList.last()) {
            if (productList.retrieve().getProductId() == productId) {
                productList.remove();
                return true;
            }
            productList.findNext();
        }
        
        // Check last element in the list
        if (productList.retrieve() != null && 
            productList.retrieve().getProductId() == productId) {
            productList.remove();
            return true;
        }
        
        return false;
    }

    // Update product information
    public boolean updateProduct(int productId, String name, double price, int stock) {
        if (productList.empty()) {
            return false;
        }
        
        // Find product to update
        productList.findFirst();
        while (!productList.last()) {
            if (productList.retrieve().getProductId() == productId) {
                productList.retrieve().updateProduct(name, price, stock);
                return true;
            }
            productList.findNext();
        }
        
        // Check last product
        if (productList.retrieve() != null && 
            productList.retrieve().getProductId() == productId) {
            productList.retrieve().updateProduct(name, price, stock);
            return true;
        }
        
        return false;
    }

    // Search for a product by ID
    public Product searchById(int id) {
        if (productList.empty()) {
            return null;
        }
        
        productList.findFirst();
        while (!productList.last()) {
            if (productList.retrieve().getProductId() == id) {
                return productList.retrieve();
            }
            productList.findNext();
        }
        
        if (productList.retrieve() != null && 
            productList.retrieve().getProductId() == id) {
            return productList.retrieve();
        }
        
        return null;
    }

    // Search for products by name
    public LinkedList<Product> searchByName(String name) {
        LinkedList<Product> results = new LinkedList<>();
        
        if (productList.empty()) {
            return results;
        }
        
        productList.findFirst();
        while (!productList.last()) {
            Product current = productList.retrieve();
            if (current.getName().toLowerCase().contains(name.toLowerCase())) {
                if (results.empty()) {
                    results.insert(current);
                } else {
                    results.findFirst();
                    while (!results.last()) {
                        results.findNext();
                    }
                    results.insert(current);
                }
            }
            productList.findNext();
        }
        
        Product lastProduct = productList.retrieve();
        if (lastProduct != null && lastProduct.getName().toLowerCase().contains(name.toLowerCase())) {
            if (results.empty()) {
                results.insert(lastProduct);
            } else {
                results.findFirst();
                while (!results.last()) {
                    results.findNext();
                }
                results.insert(lastProduct);
            }
        }
        
        return results;
    }

    // Track out of stock products
    public LinkedList<Product> getOutOfStockProducts() {
        LinkedList<Product> outOfStock = new LinkedList<>();
        
        if (productList.empty()) {
            return outOfStock;
        }
        
        productList.findFirst();
        while (!productList.last()) {
            Product product = productList.retrieve();
            if (product.isOutOfStock()) {
                if (outOfStock.empty()) {
                    outOfStock.insert(product);
                } else {
                    outOfStock.findFirst();
                    while (!outOfStock.last()) {
                        outOfStock.findNext();
                    }
                    outOfStock.insert(product);
                }
            }
            productList.findNext();
        }
        
        Product finalProduct = productList.retrieve();
        if (finalProduct != null && finalProduct.isOutOfStock()) {
            if (outOfStock.empty()) {
                outOfStock.insert(finalProduct);
            } else {
                outOfStock.findFirst();
                while (!outOfStock.last()) {
                    outOfStock.findNext();
                }
                outOfStock.insert(finalProduct);
            }
        }
        
        return outOfStock;
    }

    // Display all products
    public void displayAllProducts(boolean showReviews) {
        if (productList.empty()) {
            System.out.println("No products available.");
            return;
        }
        
        productList.findFirst();
        while (!productList.last()) {
            productList.retrieve().displayProduct(showReviews);
            productList.findNext();
        }
        productList.retrieve().displayProduct(showReviews);
    }

    public void displayAllProducts() {
        displayAllProducts(false);
    }

    // Load products from dataset file
    public void loadProducts(String filePath) {
        try (Scanner scanner = new Scanner(new File(filePath))) {
            scanner.nextLine(); // Skip header
            int count = 0;
            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                int productId = Integer.parseInt(data[0]);
                String name = data[1];
                double price = Double.parseDouble(data[2]);
                int stock = Integer.parseInt(data[3]);

                Product product = new Product(productId, name, price, stock);
                addProduct(product);
                count++;
            }
            System.out.println(count + " products loaded successfully!");
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
        } catch (Exception e) {
            System.out.println("Error reading products file: " + e.getMessage());
        }
    }

    // Load reviews from dataset file
    public void loadReviews(String filePath) {
        try (Scanner scanner = new Scanner(new File(filePath))) {
            scanner.nextLine(); // Skip header
            int count = 0;
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (!line.isEmpty()) {
                    String[] data = line.split(",", 5);
                    
                    if (data.length >= 5) {
                        String customerId = data[2];
                        int productId = Integer.parseInt(data[1]);
                        int rating = Integer.parseInt(data[3]);
                        String comment = data[4].replace("\"", "");
                    
                        Review review = new Review(customerId, rating, comment);
                        Product product = searchById(productId);

                        if (product != null) {
                            product.addReview(review);
                            count++;
                        }
                    }
                }
            }
            System.out.println(count + " reviews loaded successfully!");
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
        } catch (Exception e) {
            System.out.println("Error reading reviews file: " + e.getMessage());
        }
    }

    // Load all data
    public void loadAllData(String productsFile, String reviewsFile) {
        loadProducts(productsFile);
        loadReviews(reviewsFile);
    }

    // Extract reviews from a specific customer
    public LinkedList<Review> getReviewsByCustomer(String customerId) {
        LinkedList<Review> customerReviews = new LinkedList<>();
        
        if (productList.empty()) {
            return customerReviews;
        }
        
        productList.findFirst();
        while (!productList.last()) {
            Product product = productList.retrieve();
            LinkedList<Review> productReviews = product.getReviews();
            
            if (!productReviews.empty()) {
                productReviews.findFirst();
                while (!productReviews.last()) {
                    Review review = productReviews.retrieve();
                    if (review.getCustomerId().equals(customerId)) {
                        if (customerReviews.empty()) {
                            customerReviews.insert(review);
                        } else {
                            customerReviews.findFirst();
                            while (!customerReviews.last()) {
                                customerReviews.findNext();
                            }
                            customerReviews.insert(review);
                        }
                    }
                    productReviews.findNext();
                }
                Review lastReview = productReviews.retrieve();
                if (lastReview != null && lastReview.getCustomerId().equals(customerId)) {
                    if (customerReviews.empty()) {
                        customerReviews.insert(lastReview);
                    } else {
                        customerReviews.findFirst();
                        while (!customerReviews.last()) {
                            customerReviews.findNext();
                        }
                        customerReviews.insert(lastReview);
                    }
                }
            }
            productList.findNext();
        }
        
        return customerReviews;
    }

    // Suggest top 3 products by average rating
    public void displayTop3RatedProducts() {
        if (productList.empty()) {
          System.out.println("No products available.");
          return;
        }
    
        Product first = null, second = null, third = null;
    
        productList.findFirst();
        while (!productList.last()) {
           Product product = productList.retrieve();
           double rating = product.getAverageRating();
        
         if (first == null || rating > first.getAverageRating()) {
              third = second;
              second = first;
              first = product;
            } else if (second == null || rating > second.getAverageRating()) {
              third = second;
            second = product;
         } else if (third == null || rating > third.getAverageRating()) {
              third = product;
         }
         productList.findNext();
        }
        
        Product lastProduct = productList.retrieve();
        if (lastProduct != null) {
            double rating = lastProduct.getAverageRating();
            if (first == null || rating > first.getAverageRating()) {
                third = second;
                second = first;
                first = lastProduct;
            } else if (second == null || rating > second.getAverageRating()) {
                third = second;
                second = lastProduct;
            } else if (third == null || rating > third.getAverageRating()) {
                third = lastProduct;
            }
        }

        System.out.println("TOP 3 RATED PRODUCTS:");
        if (first != null) {
            System.out.println("1. " + first.getName() + " | Rating: " + String.format("%.2f", first.getAverageRating()) + "/5" + " - Price: " + first.getPrice()+" SR");
        }
        if (second != null) {
            System.out.println("2. " + second.getName() + " | Rating: " + String.format("%.2f", second.getAverageRating()) + "/5" + " - Price: " + second.getPrice()+" SR");
        }
        if (third != null) {
            System.out.println("3. " + third.getName() + " | Rating: " + String.format("%.2f", third.getAverageRating()) + "/5" + " - Price: " + third.getPrice()+" SR");
        }
    }

    // Show common products with rating > 4 between two customers
    public void displayCommonHighlyRatedProducts(String custId1, String custId2) {
        LinkedList<Product> commonProducts = new LinkedList<>();
        
        if (productList.empty()) {
            System.out.println("No products available.");
            return;
        }
        
        productList.findFirst();
        while (!productList.last()) {
            Product product = productList.retrieve();
            
            if (product.getAverageRating() > 4.0) {
                boolean cust1Reviewed = false;
                boolean cust2Reviewed = false;
                
                LinkedList<Review> productReviews = product.getReviews();
                if (!productReviews.empty()) {
                    productReviews.findFirst();
                    while (!productReviews.last()) {
                        Review review = productReviews.retrieve();
                        if (review.getCustomerId().equals(custId1)) {
                            cust1Reviewed = true;
                        }
                        if (review.getCustomerId().equals(custId2)) {
                            cust2Reviewed = true;
                        }
                        productReviews.findNext();
                    }
                    Review lastReview = productReviews.retrieve();
                    if (lastReview != null) {
                        if (lastReview.getCustomerId().equals(custId1)) cust1Reviewed = true;
                        if (lastReview.getCustomerId().equals(custId2)) cust2Reviewed = true;
                    }
                }
                
                if (cust1Reviewed && cust2Reviewed) {
                    if (commonProducts.empty()) {
                        commonProducts.insert(product);
                    } else {
                        commonProducts.findFirst();
                        while (!commonProducts.last()) {
                            commonProducts.findNext();
                        }
                        commonProducts.insert(product);
                    }
                }
            }
            productList.findNext();
        }
        
        if (commonProducts.empty()) {
            System.out.println("No common highly rated products found.");
        } else {
            System.out.println("Common highly rated products (rating > 4/5) for customers: " + custId1 + " & " + custId2);
            commonProducts.displayAll();
        }
    }
    
    // Edit review for a product
    public boolean editReview(int productId, String customerId, int newRating, String newComment) {
        Product product = searchById(productId);
        if (product != null) {
            LinkedList<Review> productReviews = product.getReviews();
            
            if (!productReviews.empty()) {
                productReviews.findFirst();
                while (!productReviews.last()) {
                    Review review = productReviews.retrieve();
                    if (review.getCustomerId().equals(customerId)) {
                        review.setRating(newRating);
                        review.setComment(newComment);
                        return true;
                    }
                    productReviews.findNext();
                }
                Review lastReview = productReviews.retrieve();
                if (lastReview != null && lastReview.getCustomerId().equals(customerId)) {
                    lastReview.setRating(newRating);
                    lastReview.setComment(newComment);
                    return true;
                }
            }
        }
        return false;
    }
}