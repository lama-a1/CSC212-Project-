/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

/**
 *
 * @author memem
 */
import java.util.Scanner;

public class Main {
    private static final String PRODUCTS_CSV = "src/csc212project/prodcuts.csv";
    private static final String REVIEWS_CSV = "src/csc212project/reviews.csv";
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Products productsSystem = new Products();
        int choice;
        
        System.out.println("Loading data from CSV files..");
        productsSystem.loadAllData(PRODUCTS_CSV, REVIEWS_CSV);
        System.out.println("************************************");
        
        do {
            System.out.println("\n=== WELCOME TO MANAGEMENT SYSTEM ===");
            System.out.println("************************************");
            System.out.println("1. Products");
            System.out.println("2. Customers");
            System.out.println("3. Orders");
            System.out.println("4. Reviews");
            System.out.println("5. Exit");
            System.out.print("Choose an option (1-5)\nEnter your choice: ");
            
            choice = scanner.nextInt();
            scanner.nextLine();
            
            switch (choice) {
                case 1: productsMenu(productsSystem, scanner); break;
                case 2: customersMenu(productsSystem, scanner); break;
                case 3: ordersMenu(productsSystem, scanner); break;
                case 4: reviewsMenu(productsSystem, scanner); break;
                case 5: System.out.println("Thank you for using our system!\nGoodbye!"); break;
                default: System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 5);
        
        scanner.close();
    }
    
    // Products sub-menu for product management operations
    public static void productsMenu(Products productsSystem, Scanner scanner) {
        int choice;
        do {
            System.out.println("\n=== PRODUCT MANAGEMENT ===");
            System.out.println("1. Add new product");
            System.out.println("2. Remove product");
            System.out.println("3. Update product");
            System.out.println("4. Search products by ID");
            System.out.println("5. Search products by name");
            System.out.println("6. Track all Out of stock products");
            System.out.println("7. Return to Main menu");
            System.out.print("Enter your choice: ");
            
            choice = scanner.nextInt();
            scanner.nextLine();
            
            switch (choice) {
                case 1: addNewProduct(productsSystem, scanner); break;
                case 2: removeProduct(productsSystem, scanner); break;
                case 3: updateProduct(productsSystem, scanner); break;
                case 4: searchProductById(productsSystem, scanner); break;
                case 5: searchProductByName(productsSystem, scanner); break;
                case 6: displayOutOfStock(productsSystem); break;
                case 7: System.out.println("Returning to main menu..."); break;
                default: System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 7);
    }
    
    // Reviews sub-menu for review management operations
    public static void reviewsMenu(Products productsSystem, Scanner scanner) {
        int choice;
        do {
            System.out.println("\n=== REVIEW MANAGEMENT ===");
            System.out.println("1. Add review");
            System.out.println("2. Edit review");
            System.out.println("3. Get average rating for product");
            System.out.println("4. Top 3 products");
            System.out.println("5. Common products (rating > 4/5) between 2 customers");
            System.out.println("6. Return to Main menu");
            System.out.print("Enter your choice: ");
            
            choice = scanner.nextInt();
            scanner.nextLine();
            
            switch (choice) {
                case 1: addReviewToProduct(productsSystem, scanner); break;
                case 2: editReview(productsSystem, scanner); break;
                case 3: getAverageRatingForProduct(productsSystem, scanner); break;
                case 4: displayTop3RatedProducts(productsSystem); break;
                case 5: getCommonHighlyRatedProducts(productsSystem, scanner); break;
                case 6: System.out.println("Returning to main menu..."); break;
                default: System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 6);
    }
    
    // Customers sub-menu for customer-related operations
    public static void customersMenu(Products productsSystem, Scanner scanner) {
        int choice;
        do {
             System.out.println("\n=== CUSTOMER MANAGEMENT ===");
            System.out.println("1. Get reviews by customer");
            System.out.println("2. Return to Main menu");
            System.out.print("Enter your choice: ");
            
            choice = scanner.nextInt();
            scanner.nextLine();
            
            switch (choice) {
                case 1: getReviewsByCustomer(productsSystem, scanner); break;
                case 2: System.out.println("Returning to main menu..."); break;
                default: System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 2);
    }
    
    // Orders sub-menu
    public static void ordersMenu(Products productsSystem, Scanner scanner) {
        System.out.println("\n=== ORDER MANAGEMENT ===");
        System.out.println("Orders functionality - Under development");
        System.out.println("Press Enter to return...");
        scanner.nextLine();
    }
    
    // Add a new product to the system
    public static void addNewProduct(Products productsSystem, Scanner scanner) {
        System.out.println("Add New Product:");
        System.out.print("Enter Product ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Product Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter Stock Quantity: ");
        int stock = scanner.nextInt();
        
        Product newProduct = new Product(id, name, price, stock);
        productsSystem.addProduct(newProduct);
        System.out.println("Product added successfully!");
    }
    
    // Remove a product from the system
    public static void removeProduct(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID to remove: ");
        int id = scanner.nextInt();
        
        if (productsSystem.removeProduct(id)) {
            System.out.println("Product removed successfully!");
        } else {
            System.out.println("Product not found!");
        }
    }
    
    // Update product information
    public static void updateProduct(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        
        Product existing = productsSystem.searchById(id);
        if (existing != null) {
            System.out.print("Enter new Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new Price: ");
            double price = scanner.nextDouble();
            System.out.print("Enter new Stock: ");
            int stock = scanner.nextInt();
            
            productsSystem.updateProduct(id, name, price, stock);
            System.out.println("Product updated successfully!");
        } else {
            System.out.println("Product not found!");
        }
    }
    
    // Search for product by ID
    public static void searchProductById(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID to search: ");
        int id = scanner.nextInt();
        Product product = productsSystem.searchById(id);
        
        if (product != null) {
            System.out.println("Product Found:");
            product.displayProduct(true);
        } else {
            System.out.println("Product with ID " + id + " not found!");
        }
    }
    
    // Search for products by name
    public static void searchProductByName(Products productsSystem, Scanner scanner) {
        System.out.print("Enter product name to search: ");
        String name = scanner.nextLine();
        LinkedList<Product> results = productsSystem.searchByName(name);
        
        // Check if list is empty instead of using size()
        if (!results.empty()) {
            System.out.println("Search Results:");
            results.displayAll();
        } else {
            System.out.println("No products found with name: " + name);
        }
    }
    
    // Display all out-of-stock products
    public static void displayOutOfStock(Products productsSystem) {
        LinkedList<Product> outOfStock = productsSystem.getOutOfStockProducts();
        
        if (!outOfStock.empty()) {
            System.out.println("Out of Stock Products:");
            outOfStock.displayAll();
        } else {
            System.out.println("NO products out of stock..\nAll products are in stock!");
        }
    }
    
    // Add a review to a product
    public static void addReviewToProduct(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID to review: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        
        Product product = productsSystem.searchById(productId);
        if (product != null) {
            System.out.print("Enter Customer ID: ");
            String customerId = scanner.nextLine();
            System.out.print("Enter Rating (1-5): ");
            int rating = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter Comment: ");
            String comment = scanner.nextLine();
            
            Review review = new Review(customerId, rating, comment);
            product.addReview(review);
            System.out.println("Review added successfully!");
        } else {
            System.out.println("Product not found!");
        }
    }
    
    // Edit an existing review
    public static void editReview(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Customer ID: ");
        String customerId = scanner.nextLine();
        System.out.print("Enter new Rating (1-5): ");
        int newRating = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter new Comment: ");
        String newComment = scanner.nextLine();
        
        if (productsSystem.editReview(productId, customerId, newRating, newComment)) {
            System.out.println("Review updated successfully!");
        } else {
            System.out.println("Review not found or update failed!");
        }
    }
    
    // Get average rating for a specific product
    public static void getAverageRatingForProduct(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID: ");
        int productId = scanner.nextInt();
        Product product = productsSystem.searchById(productId);
        
        if (product != null) {
            double avgRating = product.getAverageRating();
            System.out.println("Average rating for " + product.getName() + ": " + 
                String.format("%.2f", avgRating) + "/5");
        } else {
            System.out.println("Product not found!");
        }
    }
    
    // Display top 3 rated products
    public static void displayTop3RatedProducts(Products productsSystem) {
        productsSystem.displayTop3RatedProducts();
    }
    
    // Get common highly rated products between two customers
    public static void getCommonHighlyRatedProducts(Products productsSystem, Scanner scanner) {
        System.out.print("Enter first customer ID: ");
        String custId1 = scanner.nextLine();
        System.out.print("Enter second customer ID: ");
        String custId2 = scanner.nextLine();
        
        productsSystem.displayCommonHighlyRatedProducts(custId1, custId2);
    }
    
    // Get all reviews by a specific customer
    public static void getReviewsByCustomer(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Customer ID: ");
        String customerId = scanner.nextLine();
        
        LinkedList<Review> customerReviews = productsSystem.getReviewsByCustomer(customerId);
        if (!customerReviews.empty()) {
            System.out.println("Reviews by customer " + customerId + ":");
            customerReviews.displayAll();
        } else {
            System.out.println("No reviews found for customer: " + customerId);
        }
    }
}

/*
import java.util.Scanner;

public class Main {
    private static final String PRODUCTS_CSV = "src/csc212project/prodcuts.csv";
    private static final String REVIEWS_CSV = "src/csc212project/reviews.csv";
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Products productsSystem = new Products();
        int choice;
        
        System.out.println("loading data from CSV files");
        productsSystem.loadAllData(PRODUCTS_CSV, REVIEWS_CSV);
        System.out.println("********************");
        
        do {
            System.out.println("************************************");
            System.out.println("1. Products");
            System.out.println("2. Customers");
            System.out.println("3. Orders");
            System.out.println("4. Reviews");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
            choice = scanner.nextInt();
            scanner.nextLine();
            
            switch (choice) {
                case 1: productsMenu(productsSystem, scanner); break;
                case 2: customersMenu(productsSystem, scanner); break;
                case 3: ordersMenu(productsSystem, scanner); break;
                case 4: reviewsMenu(productsSystem, scanner); break;
                case 5: System.out.println("Thank you for using our system!"); break;
                default: System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 5);
        
        scanner.close();
    }
    
    // Products sub-menu for product management operations
    public static void productsMenu(Products productsSystem, Scanner scanner) {
        int choice;
        do {
            System.out.println("\n1. Add new product");
            System.out.println("2. Remove product");
            System.out.println("3. Update product");
            System.out.println("4. Search products by ID");
            System.out.println("5. Search products by name");
            System.out.println("6. Track all Out of stock products");
            System.out.println("7. Return Main menu");
            System.out.print("Enter your choice: ");
            
            choice = scanner.nextInt();
            scanner.nextLine();
            
            switch (choice) {
                case 1: addNewProduct(productsSystem, scanner); 
                    break;
                case 2: removeProduct(productsSystem, scanner); 
                    break;
                case 3: updateProduct(productsSystem, scanner); 
                break;
                case 4: searchProductById(productsSystem, scanner);
                     break;
                case 5: searchProductByName(productsSystem, scanner); 
                    break;
                case 6: displayOutOfStock(productsSystem); 
                    break;
                case 7: System.out.println("Returning to main menu...");
                    break;
                default: System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 7);
    }
    
    // Reviews sub-menu for review management operations
    public static void reviewsMenu(Products productsSystem, Scanner scanner) {
        int choice;
        do {
            System.out.println("\n1. Add review");
            System.out.println("2. Edit review (rating, comment)");
            System.out.println("3. Get an average rating for product");
            System.out.println("4. Top 3 products");
            System.out.println("5. Common products (reviwed average rating > 4/5) between 2 customers");
            System.out.println("6. Return Main menu");
            System.out.print("Enter your choice: ");
            
            choice = scanner.nextInt();
            scanner.nextLine();
            
            switch (choice) {
                case 1: addReviewToProduct(productsSystem, scanner); 
                break;
                case 2: editReview(productsSystem, scanner); 
                break;
                case 3: getAverageRatingForProduct(productsSystem, scanner); break;
                case 4: displayTop3RatedProducts(productsSystem); break;
                case 5: getCommonHighlyRatedProducts(productsSystem, scanner); break;
                case 6: System.out.println("Returning to main menu..."); break;
                default: System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 6);
    }
    
    // Customers sub-menu for customer-related operations
    public static void customersMenu(Products productsSystem, Scanner scanner) {
        int choice;
        do {
            System.out.println("\n1. Get reviews by customer");
            System.out.println("2. Return Main menu");
            System.out.print("Enter your choice: ");
            
            choice = scanner.nextInt();
            scanner.nextLine();
            
            switch (choice) {
                case 1: getReviewsByCustomer(productsSystem, scanner); break;
                case 2: System.out.println("Returning to main menu..."); break;
                default: System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 2);
    }
    
    // Orders sub-menu (placeholder for future implementation)
    public static void ordersMenu(Products productsSystem, Scanner scanner) {
        System.out.println("\nOrders functionality - Under development");
        System.out.println("Press Enter to return...");
        scanner.nextLine();
    }
    
    // Add a new product to the system
    public static void addNewProduct(Products productsSystem, Scanner scanner) {
        System.out.println("Add New Product:");
        System.out.print("Enter Product ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Product Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter Stock Quantity: ");
        int stock = scanner.nextInt();
        
        Product newProduct = new Product(id, name, price, stock);
        productsSystem.addProduct(newProduct);
        System.out.println("Product added successfully!");
    }
    
    // Remove a product from the system
    public static void removeProduct(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID to remove: ");
        int id = scanner.nextInt();
        
        if (productsSystem.removeProduct(id)) {
            System.out.println("Product removed successfully!");
        } else {
            System.out.println("Product not found!");
        }
    }
    
    // Update product information
    public static void updateProduct(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        
        Product existing = productsSystem.searchById(id);
        if (existing != null) {
            System.out.print("Enter new Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new Price: ");
            double price = scanner.nextDouble();
            System.out.print("Enter new Stock: ");
            int stock = scanner.nextInt();
            
            productsSystem.updateProduct(id, name, price, stock);
            System.out.println("Product updated successfully!");
        } else {
            System.out.println("Product not found!");
        }
    }
    
    // Search for product by ID using linear search
    public static void searchProductById(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID to search: ");
        int id = scanner.nextInt();
        Product product = productsSystem.searchById(id);
        
        if (product != null) {
            System.out.println("Product Found:");
            product.displayProduct(true);
        } else {
            System.out.println("Product with ID " + id + " not found!");
        }
        }
    
    // Search for products by name using linear search
    public static void searchProductByName(Products productsSystem, Scanner scanner) {
        System.out.print("Enter product name to search: ");
        String name = scanner.nextLine();
        LinkedList<Product> results = productsSystem.searchByName(name);
        
        if (results.size() > 0) {
            System.out.println("Search Results (" + results.size() + " products):");
            results.displayAll();
        } else {
            System.out.println("No products found with name: " + name);
        }
    }
    
    // Display all out-of-stock products
    public static void displayOutOfStock(Products productsSystem) {
        LinkedList<Product> outOfStock = productsSystem.getOutOfStockProducts();
        
        if (outOfStock.size() > 0) {
            System.out.println("Out of Stock Products:");
            outOfStock.displayAll();
        } else {
            System.out.println("All products are in stock!");
        }
    }
    
    // Add a review to a product
    public static void addReviewToProduct(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID to review: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        
        Product product = productsSystem.searchById(productId);
        if (product != null) {
            System.out.print("Enter Customer ID: ");
            String customerId = scanner.nextLine();
            System.out.print("Enter Rating (1-5): ");
            int rating = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter Comment: ");
            String comment = scanner.nextLine();
            
            Review review = new Review(customerId, rating, comment);
            product.addReview(review);
            System.out.println("Review added successfully!");
        } else {
            System.out.println("Product not found!");
        }
    }
    
    // Edit an existing review
    public static void editReview(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Customer ID: ");
        String customerId = scanner.nextLine();
        System.out.print("Enter new Rating (1-5): ");
        int newRating = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter new Comment: ");
        String newComment = scanner.nextLine();
        
        if (productsSystem.editReview(productId, customerId, newRating, newComment)) {
            System.out.println("Review updated successfully!");
        } else {
            System.out.println("Review not found or update failed!");
        }
    }
    
    // Get average rating for a specific product
    public static void getAverageRatingForProduct(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Product ID: ");
        int productId = scanner.nextInt();
        Product product = productsSystem.searchById(productId);
        
        if (product != null) {
            double avgRating = product.getAverageRating();
            System.out.println("Average rating for " + product.getName() + ": " + String.format("%.2f", avgRating) + "/5");
        } else {
            System.out.println("Product not found!");
        }
    }
    
    // Display top 3 rated products
    public static void displayTop3RatedProducts(Products productsSystem) {
        productsSystem.displayTop3RatedProducts();
    }
    
    // Get common highly rated products between two customers
    public static void getCommonHighlyRatedProducts(Products productsSystem, Scanner scanner) {
        System.out.print("Enter first customer ID: ");
        String custId1 = scanner.nextLine();
        System.out.print("Enter second customer ID: ");
        String custId2 = scanner.nextLine();
        
        productsSystem.displayCommonHighlyRatedProducts(custId1, custId2);
    }
    
    // Get all reviews by a specific customer
    public static void getReviewsByCustomer(Products productsSystem, Scanner scanner) {
        System.out.print("Enter Customer ID: ");
        String customerId = scanner.nextLine();
        
        LinkedList<Review> customerReviews = productsSystem.getReviewsByCustomer(customerId);
        if (customerReviews.size() > 0) {
            System.out.println("Reviews by customer " + customerId + ":");
            customerReviews.displayAll();
        } else {
            System.out.println("No reviews found for customer: " + customerId);
        }
    }
}*/
