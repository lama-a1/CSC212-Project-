/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

/**
 *
 * @author memem
 */
class Node<T> {
	public T data;
	public Node<T> next;
	public Node (T val) {
		data = val;
		next = null;
	}
}

public class LinkedList<T> {
    private Node<T> head;
    private Node<T> current;
    public int size;

    // Check if list has no elements
    public boolean empty() { 
        return head == null; 
    }
    
    // Check if current pointer is at the last element
    public boolean last() { 
        return current == null || current.next == null; 
    }
    
    // Reset current pointer to the first element
    public void findFirst() { 
        current = head; 
    }
    
    // Move current pointer to the next element
    public void findNext() { 
        if (current != null) 
            current = current.next; 
    }
    
    // Get data from current position
    public T retrieve() { 
        return (current != null) ? current.data : null; 
    }
    
    // Update data at current position
    public void update(T val) { 
        if (current != null) 
            current.data = val; 
    }
    
    public void insert(T val) {
       Node<T> tmp;
        if (empty()) {
            current = head = new Node<T> (val);
        }
        else {
            tmp = current.next;
            current.next = new Node<T> (val);
            current = current.next;
            current.next = tmp;
        }
    }

    public void remove() {
        if (current == head) {
            head = head.next;
        }
        else {
            Node<T> tmp = head;
            while (tmp.next != current)
                tmp = tmp.next;
            tmp.next = current.next;
        }
        if (current.next == null)
            current = head;
        else
            current = current.next;
    }
    
    // Display all elements in the list
    public void displayAll() {
    if (empty()) { 
        System.out.println("List is empty");
        return;
    }
    
    Node<T> temp = head;
    while (temp != null) {
        System.out.print(temp.data + " ");
        temp = temp.next;
    }
    System.out.println();
}
    
    // Check if specific element exists in list
    public boolean exists(T target) {
        Node<T> temp = head;
        while (temp != null) {
            if (temp.data.equals(target))    
                return true;
            temp = temp.next;
        }
        return false;
    }
}