/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

/**
 *
 * @author memem
 */
public class Product {
    private int productId;
    private String name;
    private double price;
    private int stock;
    private LinkedList<Review> reviews;

    public Product(int productId, String name, double price, int stock) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.reviews = new LinkedList<>();
    }

    // Getters
    public int getProductId() { return productId; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getStock() { return stock; }
    public LinkedList<Review> getReviews() { return reviews; }

    // Setters
    public void setStock(int stock) { this.stock = stock; }

    // Update product information
    public void updateProduct(String name, double price, int stock) {
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    // Stock management
    public void decreaseStock(int quantity) {
        if (this.stock >= quantity) {
            this.stock -= quantity;
        }
    }

    public void increaseStock(int quantity) {
        this.stock += quantity;
    }

    public boolean isOutOfStock() {
        return stock == 0;
    }

    // Add a new review to this product
    public void addReview(Review review) {
        if (reviews.empty()) {
            reviews.insert(review);
        } else {
            reviews.findFirst();
            while (!reviews.last()) {
                reviews.findNext();
            }
            reviews.insert(review);
        }
    }

    // Calculate average rating
    public double getAverageRating() {
        if (reviews.empty()) return 0.0;

        double total = 0;
        int count = 0;
        
        // Use iterator methods instead of direct Node access
        reviews.findFirst();
        while (!reviews.last()) {
            total += reviews.retrieve().getRating();
            count++;
            reviews.findNext();
        }
        // Add last review
        total += reviews.retrieve().getRating();
        count++;
        
        return total / count;
    }

    // Display product details
    public void displayProduct(boolean showReviews) {
        System.out.println("Product ID: " + productId + " | Name: " + name + " | Price: " + price + " SR"+ " | Stock: " + stock);
        
        if (showReviews) {
            System.out.println("Reviews:");
            reviews.displayAll();
        }
        System.out.println("--------------------------------------------------");
    }

    public void displayProduct() {
        displayProduct(false);
    }

    @Override
    public String toString() {
        return "Product ID: " + productId + ", Name: " + name + ", Price: " + price + " SR"+ ", Stock: " + stock +"\n";
    }
}

/*
public class Product {
    private int productId;
    private String name;
    private double price;
    private int stock;
    private LinkedList<Review> reviews;

    public Product(int productId, String name, double price, int stock) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.reviews = new LinkedList<>();
    }

    // Getters
    public int getProductId() { return productId; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getStock() { return stock; }
    public LinkedList<Review> getReviews() { return reviews; }

    // Setters
    public void setStock(int stock) { this.stock = stock; }

    // Update product information
    public void updateProduct(String name, double price, int stock) {
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    // Stock management
    public void decreaseStock(int quantity) {
        if (this.stock >= quantity) {
            this.stock -= quantity;
        }
    }

    public void increaseStock(int quantity) {
        this.stock += quantity;
    }

    public boolean isOutOfStock() {
        return stock == 0;
    }

    // Add a new review to this product
    public void addReview(Review review) {
        reviews.insertAtEnd(review);
    }

    // Calculate average rating
    public double getAverageRating() {
        if (reviews.isEmpty()) return 0.0;

        double total = 0;
        int count = 0;
        LinkedList.Node<Review> current = reviews.getHead();

        while (current != null) {
            total += current.data.getRating();
            count++;
            current = current.next;
        }
        return total / count;
    }

    // Display product details
    public void displayProduct(boolean showReviews) {
        System.out.println("Product ID: " + productId + " | Name: " + name + " | Price: " + price + " | Stock: " + stock);
        System.out.println("Average Rating: " + String.format("%.2f", getAverageRating()));
        
        if (showReviews) {
            System.out.println("Reviews:");
            reviews.displayAll();
        }
        System.out.println("--------------------------------------------------");
    }

    public void displayProduct() {
        displayProduct(false);
    }

    @Override
    public String toString() {
        return "Product:\n Product ID: " + productId + ", Name: " + name + ", Price: " + price + ", Stock: " + stock ;
    }
}*/
