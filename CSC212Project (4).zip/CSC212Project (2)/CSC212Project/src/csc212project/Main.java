/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

import java.util.Scanner;

/**
 *
 * @author memem
 */
public class Main {

    private static final String PRODUCTS_CSV  = "src/csc212project/prodcuts.csv";
    private static final String REVIEWS_CSV   = "src/csc212project/reviews.csv";
    private static final String CUSTOMERS_CSV = "src/csc212project/customers.csv";
    private static final String ORDERS_CSV    = "src/csc212project/orders.csv";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Products productsSystem = new Products();
        int choice;

        System.out.println("Loading data from CSV files..");
        productsSystem.loadAllData(PRODUCTS_CSV, REVIEWS_CSV, CUSTOMERS_CSV, ORDERS_CSV);
      
        System.out.println("************************************");

        do {
            System.out.println("\n=== WELCOME TO MANAGEMENT SYSTEM ===");
            System.out.println("************************************");
            System.out.println("1. Products");
            System.out.println("2. Customers");
            System.out.println("3. Orders");
            System.out.println("4. Reviews");
            System.out.println("5. Exit");
            System.out.print("Choose an option (1-5)\nEnter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine();

            // ===== MAIN SWITCH =====
            if (choice == 1) {
                // ============ PRODUCTS MENU ============
                int pChoice;
                do {
                    System.out.println("\n=== PRODUCT MANAGEMENT ===");
                    System.out.println("1. Add new product");
                    System.out.println("2. Remove product");
                    System.out.println("3. Update product");
                    System.out.println("4. Search products by ID");
                    System.out.println("5. Search products by name");
                    System.out.println("6. Track all Out of stock products");
                    System.out.println("7. Return to Main menu");
                    System.out.print("Enter your choice: ");

                    pChoice = scanner.nextInt();
                    scanner.nextLine();

                    if (pChoice == 1) {
                        System.out.println("Add New Product:");
                        System.out.print("Enter Product ID: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Product Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter Price: ");
                        double price = scanner.nextDouble();
                        System.out.print("Enter Stock Quantity: ");
                        int stock = scanner.nextInt();

                        Product newProduct = new Product(id, name, price, stock);
                        productsSystem.addProduct(newProduct);
                        System.out.println("Product added successfully!");

                    } else if (pChoice == 2) {
                        System.out.print("Enter Product ID to remove: ");
                        int id = scanner.nextInt();

                        if (productsSystem.removeProduct(id)) {
                            System.out.println("Product removed successfully!");
                        } else {
                            System.out.println("Product not found!");
                        }

                    } else if (pChoice == 3) {
                        System.out.print("Enter Product ID to update: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();

                        Product existing = productsSystem.searchById(id);
                        if (existing != null) {
                            System.out.print("Enter new Name: ");
                            String name = scanner.nextLine();
                            System.out.print("Enter new Price: ");
                            double price = scanner.nextDouble();
                            System.out.print("Enter new Stock: ");
                            int stock = scanner.nextInt();

                            productsSystem.updateProduct(id, name, price, stock);
                            System.out.println("Product updated successfully!");
                        } else {
                            System.out.println("Product not found!");
                        }

                    } else if (pChoice == 4) {
                        System.out.print("Enter Product ID to search: ");
                        int id = scanner.nextInt();
                        Product product = productsSystem.searchById(id);

                        if (product != null) {
                            System.out.println("Product Found:");
                            product.displayProduct(true);
                        } else {
                            System.out.println("Product with ID " + id + " not found!");
                        }

                    } else if (pChoice == 5) {
                        System.out.print("Enter product name to search: ");
                        String name = scanner.nextLine();
                        LinkedList<Product> results = productsSystem.searchByName(name);

                        if (!results.empty()) {
                            System.out.println("Search Results:");
                            results.displayAll();
                        } else {
                            System.out.println("No products found with name: " + name);
                        }

                    } else if (pChoice == 6) {
                        LinkedList<Product> outOfStock = productsSystem.getOutOfStockProducts();

                        if (!outOfStock.empty()) {
                            System.out.println("Out of Stock Products:");
                            outOfStock.displayAll();
                        } else {
                            System.out.println("NO products out of stock..\nAll products are in stock!");
                        }

                    } else if (pChoice == 7) {
                        System.out.println("Returning to main menu...");
                    } else {
                        System.out.println("Invalid choice! Please try again.");
                    }

                } while (pChoice != 7);

            } else if (choice == 2) {
                // ============ CUSTOMERS MENU ============
                int cChoice;
                do {
                    System.out.println("\n=== CUSTOMER MANAGEMENT ===");
                    System.out.println("1. Register new customer");
                    System.out.println("2. Place New Order for specific customer");
                    System.out.println("3. View Order history for specific customer");
                    System.out.println("4. Return to Main menu");
                    System.out.print("Enter your choice: ");

                    cChoice = scanner.nextInt();
                    scanner.nextLine();

                    if (cChoice == 1) {
                        System.out.print("Enter customer ID : ");
                        int id = scanner.nextInt();
                        scanner.nextLine();

                        while (Customers.findCustomerById(id) != null) {
                            System.out.print("Re-Enter again, ID already available: ");
                            id = scanner.nextInt();
                            scanner.nextLine();
                        }

                        System.out.print("Enter customer Name : ");
                        String name = scanner.nextLine();

                        System.out.print("Enter customer Email : ");
                        String email = scanner.nextLine();

                        Customers.registerNewCustomer(id, name, email);
                        System.out.println("************************************");

                    } else if (cChoice == 2) {
                        // Place new order (نفس منيو الأوردَر)
                        System.out.print("Enter order ID: ");
                        int orderId = scanner.nextInt();
                        scanner.nextLine();

                        while (Orders.searchOrderById(orderId) != null) {
                            System.out.print("Re-enter order id, is available , try again\n");
                            orderId = scanner.nextInt();
                            scanner.nextLine();
                        }

                        System.out.print("Enter customer ID: ");
                        int customerId = scanner.nextInt();
                        scanner.nextLine();

                        Customers customer = Customers.findCustomerById(customerId);
                        if (customer == null) {
                            System.out.println("Customer not found. Please register the customer first.");
                        } else {
                            LinkedList<Integer> productIds = new LinkedList<>();
                            String cont;
                            do {
                                System.out.print("Enter product ID: ");
                                int productId = scanner.nextInt();
                                scanner.nextLine();

                                Product p = productsSystem.searchById(productId);

                                if (p == null) {
                                    System.out.println("No such product id");
                                } else if (p.getStock() <= 0) {
                                    System.out.println("product out stock , try another time");
                                } else {
                                    productIds.insert(productId);
                                    System.out.println("Product added to order.");
                                }

                                System.out.print("Do you want to continue adding product? (Y/N)\n");
                                cont = scanner.nextLine().trim();
                            } while (cont.equalsIgnoreCase("Y"));

                            if (productIds.empty()) {
                                System.out.println("No valid products were added. Order not created.");
                            } else {
                                System.out.print("Enter order date (e.g., 2025-11-13): ");
                                String orderDate = scanner.nextLine();

                                Orders created = Orders.createOrder(orderId, customer, productIds, orderDate, productsSystem);

                                if (created == null) {
                                    System.out.println("Order creation failed.");
                                } else {
                                    System.out.println("Order created successfully with total: " + created.getTotalPrice());
                                }
                            }
                        }

                    } else if (cChoice == 3) {
                        System.out.print("Enter customer ID : ");
                        int customerId = scanner.nextInt();
                        scanner.nextLine();

                        Customers.viewOrderHistoryForCustomer(customerId);

                    } else if (cChoice == 4) {
                        System.out.println("Returning to main menu...");
                    } else {
                        System.out.println("Invalid choice! Please try again.");
                    }

                } while (cChoice != 4);

            } else if (choice == 3) {
                // ============ ORDERS MENU ============
                int oChoice;
                do {
                    System.out.println("\n=== ORDER MANAGEMENT ===");
                    System.out.println("1. Place New Order");
                    System.out.println("2. Cancel Order");
                    System.out.println("3. Update Order (Status)");
                    System.out.println("4. Search By ID (linear)");
                    System.out.println("5. All orders between two dates");
                    System.out.println("6. Return Main menu");
                    System.out.print("Enter your choice: ");

                    oChoice = scanner.nextInt();
                    scanner.nextLine();

                    if (oChoice == 1) {
                        // نفس كود place new order
                        System.out.print("Enter order ID: ");
                        int orderId = scanner.nextInt();
                        scanner.nextLine();

                        while (Orders.searchOrderById(orderId) != null) {
                            System.out.print("Re-enter order id, is available , try again\n");
                            orderId = scanner.nextInt();
                            scanner.nextLine();
                        }

                        System.out.print("Enter customer ID: ");
                        int customerId = scanner.nextInt();
                        scanner.nextLine();

                        Customers customer = Customers.findCustomerById(customerId);
                        if (customer == null) {
                            System.out.println("Customer not found. Please register the customer first.");
                        } else {
                            LinkedList<Integer> productIds = new LinkedList<>();
                            String cont;
                            do {
                                System.out.print("Enter product ID: ");
                                int productId = scanner.nextInt();
                                scanner.nextLine();

                                Product p = productsSystem.searchById(productId);

                                if (p == null) {
                                    System.out.println("No such product id");
                                } else if (p.getStock() <= 0) {
                                    System.out.println("product out stock , try another time");
                                } else {
                                    productIds.insert(productId);
                                    System.out.println("Product added to order.");
                                }

                                System.out.print("Do you want to continue adding product? (Y/N)\n");
                                cont = scanner.nextLine().trim();
                            } while (cont.equalsIgnoreCase("Y"));

                            if (productIds.empty()) {
                                System.out.println("No valid products were added. Order not created.");
                            } else {
                                System.out.print("Enter order date (e.g., 2025-11-13): ");
                                String orderDate = scanner.nextLine();

                                Orders created = Orders.createOrder(orderId, customer, productIds, orderDate, productsSystem);

                                if (created == null) {
                                    System.out.println("Order creation failed.");
                                } else {
                                    System.out.println("Order created successfully with total: " + created.getTotalPrice());
                                }
                            }
                        }

                    } else if (oChoice == 2) {
                        System.out.print("Enter Order ID to cancel: ");
                        int orderId = scanner.nextInt();
                        scanner.nextLine();

                        if (!Orders.cancelOrderById(orderId)) {
                            System.out.println("Order not found or could not be canceled.");
                        }

                    } else if (oChoice == 3) {
                        System.out.print("Enter Order ID to update: ");
                        int orderId = scanner.nextInt();
                        scanner.nextLine();

                        System.out.print("Enter new status (pending/shipped/delivered/canceled): ");
                        String status = scanner.nextLine();

                        if (!Orders.updateOrderStatusById(orderId, status)) {
                            System.out.println("Order not found or invalid status.");
                        }

                    } else if (oChoice == 4) {
                        System.out.print("Enter Order ID to search: ");
                        int orderId = scanner.nextInt();
                        scanner.nextLine();

                        Orders o = Orders.searchOrderById(orderId);
                        if (o == null) {
                            System.out.println("Order not found.");
                        } else {
                            System.out.println("Order Found:");
                            System.out.println("ID = " + o.getOrderId());
                            System.out.println("Customer = " +
                                    (o.getCustomer() != null ? o.getCustomer().getName() : "N/A"));
                            System.out.println("Date = " + o.getOrderDate());
                            System.out.println("Total = " + o.getTotalPrice());
                            System.out.println("Status = " + o.getStatus());
                        }

                    } else if (oChoice == 5) {
                        System.out.print("Enter start date (yyyy-MM-dd): ");
                        String start = scanner.nextLine();

                        System.out.print("Enter end date   (yyyy-MM-dd): ");
                        String end = scanner.nextLine();

                        Orders.printOrdersBetweenDates(start, end);

                    } else if (oChoice == 6) {
                        System.out.println("Returning to main menu...");
                    } else {
                        System.out.println("Invalid choice! Please try again.");
                    }

                } while (oChoice != 6);

            } else if (choice == 4) {
                // ============ REVIEWS MENU ============
                int rChoice;
                do {
                    System.out.println("\n=== REVIEW MANAGEMENT ===");
                    System.out.println("1. Add review");
                    System.out.println("2. Edit review");
                    System.out.println("3. Get average rating for product");
                    System.out.println("4. Top 3 products");
                    System.out.println("5. Common products (rating > 4/5) between 2 customers");
                    System.out.println("6. Return to Main menu");
                    System.out.print("Enter your choice: ");

                    rChoice = scanner.nextInt();
                    scanner.nextLine();

                    if (rChoice == 1) {
                        System.out.print("Enter Product ID to review: ");
                        int productId = scanner.nextInt();
                        scanner.nextLine();

                        Product product = productsSystem.searchById(productId);
                        if (product != null) {
                            System.out.print("Enter Customer ID: ");
                            String customerId = scanner.nextLine();
                            System.out.print("Enter Rating (1-5): ");
                            int rating = scanner.nextInt();
                            scanner.nextLine();
                            System.out.print("Enter Comment: ");
                            String comment = scanner.nextLine();

                            Review review = new Review(customerId, rating, comment);
                            product.addReview(review);
                            System.out.println("Review added successfully!");
                        } else {
                            System.out.println("Product not found!");
                        }

                    } else if (rChoice == 2) {
                        System.out.print("Enter Product ID: ");
                        int productId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Customer ID: ");
                        String customerId = scanner.nextLine();
                        System.out.print("Enter new Rating (1-5): ");
                        int newRating = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter new Comment: ");
                        String newComment = scanner.nextLine();

                        if (productsSystem.editReview(productId, customerId, newRating, newComment)) {
                            System.out.println("Review updated successfully!");
                        } else {
                            System.out.println("Review not found or update failed!");
                        }

                    } else if (rChoice == 3) {
                        System.out.print("Enter Product ID: ");
                        int productId = scanner.nextInt();
                        Product product = productsSystem.searchById(productId);

                        if (product != null) {
                            double avgRating = product.getAverageRating();
                            System.out.println("Average rating for " + product.getName() + ": " +
                                String.format("%.2f", avgRating) + "/5");
                        } else {
                            System.out.println("Product not found!");
                        }

                    } else if (rChoice == 4) {
                        productsSystem.displayTop3RatedProducts();

                    } else if (rChoice == 5) {
                        System.out.print("Enter first customer ID: ");
                        String custId1 = scanner.nextLine();
                        System.out.print("Enter second customer ID: ");
                        String custId2 = scanner.nextLine();

                        productsSystem.displayCommonHighlyRatedProducts(custId1, custId2);

                    } else if (rChoice == 6) {
                        System.out.println("Returning to main menu...");
                    } else {
                        System.out.println("Invalid choice! Please try again.");
                    }

                } while (rChoice != 6);

            } else if (choice == 5) {
                System.out.println("Thank you for using our system!\nGoodbye!");
            } else {
                System.out.println("Invalid choice! Please try again.");
            }

        } while (choice != 5);

        scanner.close();
    }
}
