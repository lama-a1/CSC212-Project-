package csc212_project;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author memem
 */
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class AVLTree<T> {
    private Node root;
    private int size;

    private class Node {
        String key;
        T data;
        Node left, right;
        int height;

        public Node(String key, T data) {
            this.key = key;
            this.data = data;
            this.left = null;
            this.right = null;
            this.height = 1;
        }
    }

    public AVLTree() {
        root = null;
        size = 0;
    }

    public boolean empty() {
        return root == null;
    }

    public int size() {
        return size;
    }

    private int height(Node node) {
        return (node == null) ? 0 : node.height;
    }

    private int getBalance(Node node) {
        return (node == null) ? 0 : height(node.left) - height(node.right);
    }

    private Node rightRotate(Node y) {
        Node x = y.left;
        Node T2 = x.right;

        x.right = y;
        y.left = T2;

        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        return x;
    }

    private Node leftRotate(Node x) {
        Node y = x.right;
        Node T2 = y.left;

        y.left = x;
        x.right = T2;

        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;

        return y;
    }

    public void insert(String key, T data) {
        boolean existed = contains(key);
        root = insertRec(root, key, data);
        if (!existed) size++;
    }

    private Node insertRec(Node node, String key, T data) {
        if (node == null) return new Node(key, data);

        int cmp = key.compareTo(node.key);
        if (cmp < 0) node.left = insertRec(node.left, key, data);
        else if (cmp > 0) node.right = insertRec(node.right, key, data);
        else {
            node.data = data;
            return node;
        }

        node.height = 1 + Math.max(height(node.left), height(node.right));
        int balance = getBalance(node);

        if (balance > 1 && key.compareTo(node.left.key) < 0)
            return rightRotate(node);

        if (balance < -1 && key.compareTo(node.right.key) > 0)
            return leftRotate(node);

        if (balance > 1 && key.compareTo(node.left.key) > 0) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        if (balance < -1 && key.compareTo(node.right.key) < 0) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }

    public T search(String key) {
        Node node = findNode(root, key);
        return (node != null) ? node.data : null;
    }

    private Node findNode(Node node, String key) {
        if (node == null) return null;

        int cmp = key.compareTo(node.key);

        if (cmp == 0) return node;
        if (cmp < 0) return findNode(node.left, key);
        return findNode(node.right, key);
    }

    public void update(String key, T data) {
        Node node = findNode(root, key);
        if (node != null) node.data = data;
    }

    public void inOrderTraversal() {
        inOrderRec(root);
    }

    private void inOrderRec(Node node) {
        if (node != null) {
            inOrderRec(node.left);
            System.out.println(node.data.toString());
            inOrderRec(node.right);
        }
    }

    public void inOrderTraversal(Consumer<T> action) {
        inOrderRec(root, action);
    }

    private void inOrderRec(Node node, Consumer<T> action) {
        if (node != null) {
            inOrderRec(node.left, action);
            action.accept(node.data);
            inOrderRec(node.right, action);
        }
    }

    public List<T> getAllElements() {
        List<T> list = new ArrayList<>();
        inOrderRec(root, list);
        return list;
    }

    private void inOrderRec(Node node, List<T> list) {
        if (node != null) {
            inOrderRec(node.left, list);
            list.add(node.data);
            inOrderRec(node.right, list);
        }
    }

    public boolean contains(String key) {
        return search(key) != null;
    }
}
