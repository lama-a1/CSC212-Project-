/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212_project;

/**
 *
 * @author memem
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Review {
    public static AVLTree<Review> reviewsTree = new AVLTree<>();

    private int reviewId;
    private int productId;
    private int customerId;
    private int rating;
    private String comment;

    public Review(int reviewId, int productId, int customerId, int rating, String comment) {
        this.reviewId = reviewId;
        this.productId = productId;
        this.customerId = customerId;

        if (rating < 1) this.rating = 1;
        else if (rating > 5) this.rating = 5;
        else this.rating = rating;

        this.comment = (comment == null) ? "" : comment;
    }

    public int getReviewId() { return reviewId; }
    public int getProductId() { return productId; }
    public int getCustomerId() { return customerId; }
    public int getRating() { return rating; }
    public String getComment() { return comment; }

    public void setRating(int rating) {
        if (rating >= 1 && rating <= 5) this.rating = rating;
    }

    public void setComment(String comment) {
        this.comment = (comment == null) ? "" : comment;
    }

    public void display() {
        System.out.println("Customer: " + customerId +
                " | Rating: " + rating + "/5" +
                " | Comment: " + comment);
    }

    @Override
    public String toString() {
        return "Customer ID: " + customerId + ", Rating: " + rating + "/5" + ", Comment: " + comment;
    }

    public static void addReview(Review r) {
        reviewsTree.insert(String.valueOf(r.getReviewId()), r);
    }

    public static Review searchReviewById(int reviewId) {
        return reviewsTree.search(String.valueOf(reviewId));
    }

    public static AVLTree<Review> getReviewsByCustomer(int customerId) {
        AVLTree<Review> results = new AVLTree<>();

        reviewsTree.inOrderTraversal(review -> {
            if (review.getCustomerId() == customerId) {
                results.insert(String.valueOf(review.getReviewId()), review);
            }
        });

        return results;
    }

    public static void commonProducts(int c1, int c2) {
        AVLTree<Integer> customer1Products = new AVLTree<>();
        AVLTree<Integer> customer2Products = new AVLTree<>();

        reviewsTree.inOrderTraversal(review -> {
            if (review.getCustomerId() == c1) {
                Product p = Product.searchById(review.getProductId());
                if (p != null && p.getAverageRating() > 4) {
                    customer1Products.insert(String.valueOf(review.getProductId()), review.getProductId());
                }
            }
        });

        reviewsTree.inOrderTraversal(review -> {
            if (review.getCustomerId() == c2) {
                Product p = Product.searchById(review.getProductId());
                if (p != null && p.getAverageRating() > 4) {
                    customer2Products.insert(String.valueOf(review.getProductId()), review.getProductId());
                }
            }
        });

        AVLTree<Integer> commonProducts = new AVLTree<>();

        customer1Products.inOrderTraversal(productId -> {
            if (customer2Products.contains(String.valueOf(productId))) {
                commonProducts.insert(String.valueOf(productId), productId);
            }
        });

        if (commonProducts.empty()) {
            System.out.println("No common products found.");
            return;
        }

        System.out.println("Common highly rated products (rating > 4/5) for customers: " + c1 + " & " + c2);

        commonProducts.inOrderTraversal(productId -> {
            Product p = Product.searchById(productId);
            if (p != null) p.displayProduct(false);
        });
    }

    public static void loadReviews(String filePath) {
        try (Scanner scanner = new Scanner(new File(filePath))) {
            if (scanner.hasNextLine()) scanner.nextLine();

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) continue;

                String[] data = line.split(",", 5);
                if (data.length < 5) continue;

                int reviewId = Integer.parseInt(data[0]);
                int productId = Integer.parseInt(data[1]);
                int customerId = Integer.parseInt(data[2]);
                int rating = Integer.parseInt(data[3]);
                String comment = data[4].replace("\"", "");

                Review r = new Review(reviewId, productId, customerId, rating, comment);
                addReview(r);

                Product p = Product.searchById(productId);
                if (p != null) p.addReview(r);
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
        } catch (Exception e) {
            System.out.println("Error reading reviews file: " + e.getMessage());
        }
    }
}