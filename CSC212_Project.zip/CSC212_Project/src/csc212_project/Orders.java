/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212_project;

/**
 *
 * @author memem
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Orders {
    private int orderId;
    private Customers customer;
    private AVLTree<OrderItem> itemsTree;
    private String orderDate;
    private String status;
    private double totalPrice;

    private static AVLTree<Orders> ordersTree = new AVLTree<>();

    public Orders(int orderId, Customers customer, String orderDate) {
        this.orderId = orderId;
        this.customer = customer;
        this.orderDate = orderDate;
        this.status = "pending";
        this.totalPrice = 0.0;
        this.itemsTree = new AVLTree<>();
    }

    public static class OrderItem {
        private int productId;
        private int quantity;
        private double price;

        public OrderItem(int productId, int quantity, double price) {
            this.productId = productId;
            this.quantity = quantity;
            this.price = price;
        }

        public int getProductId() { return productId; }
        public int getQuantity() { return quantity; }
        public double getPrice() { return price; }
        public double getSubtotal() { return quantity * price; }
    }

    public int getOrderId() { return orderId; }
    public Customers getCustomer() { return customer; }
    public String getOrderDate() { return orderDate; }
    public String getStatus() { return status; }
    public double getTotalPrice() { return totalPrice; }
    public AVLTree<OrderItem> getItemsTree() { return itemsTree; }

    public void setStatus(String status) { this.status = status; }
    public void setCustomer(Customers customer) { this.customer = customer; }

    public void addItem(int productId, int quantity, double price) {
        String key = String.valueOf(productId);
        OrderItem item = new OrderItem(productId, quantity, price);
        itemsTree.insert(key, item);
        totalPrice += item.getSubtotal();
    }

    public static Orders createOrder(int orderId, Customers customer, AVLTree<Integer> productIds,
                                     String date, AVLTree<Product> productTree) {
        String key = String.valueOf(orderId);

        if (ordersTree.contains(key)) {
            System.out.println("Order ID already exists!");
            return null;
        }

        Orders newOrder = new Orders(orderId, customer, date);

        productIds.inOrderTraversal(productId -> {
            Product p = Product.searchById(productId);
            if (p != null && p.getStock() > 0) {
                newOrder.addItem(productId, 1, p.getPrice());
                p.decreaseStock(1);
            }
        });

        ordersTree.insert(key, newOrder);
        customer.placeOrder(newOrder);
        return newOrder;
    }

    public static Orders searchOrderById(int id) {
        return ordersTree.search(String.valueOf(id));
    }

    public static boolean cancelOrderById(int id) {
        Orders order = searchOrderById(id);
        if (order == null || !order.getStatus().equals("pending")) return false;

        order.setStatus("canceled");

        order.itemsTree.inOrderTraversal(item -> {
            Product p = Product.searchById(item.getProductId());
            if (p != null) p.increaseStock(item.getQuantity());
        });

        System.out.println("Order " + id + " canceled successfully.");
        return true;
    }

    public static boolean updateOrderStatusById(int id, String newStatus) {
        Orders order = searchOrderById(id);
        if (order == null) return false;

        order.setStatus(newStatus);
        System.out.println("Order " + id + " status updated to: " + newStatus);
        return true;
    }

    public static void loadOrders(String filePath) {
        try (Scanner scanner = new Scanner(new File(filePath))) {
            if (scanner.hasNextLine()) scanner.nextLine();

            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                if (data.length < 6) continue;

                int orderId = Integer.parseInt(data[0]);
                int customerId = Integer.parseInt(data[1]);

                String productIdsStr = data[2].replace("\"", "");
                String date = data[4];
                String status = data[5];

                Customers customer = Customers.findCustomerById(customerId);
                if (customer == null) continue;

                Orders order = new Orders(orderId, customer, date);
                order.setStatus(status);

                String[] productIds = productIdsStr.split(";");
                for (String pid : productIds) {
                    if (!pid.trim().isEmpty()) {
                        try {
                            int productId = Integer.parseInt(pid.trim());
                            Product p = Product.searchById(productId);
                            if (p != null) order.addItem(productId, 1, p.getPrice());
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid product ID: " + pid);
                        }
                    }
                }

                ordersTree.insert(String.valueOf(orderId), order);
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
        } catch (Exception e) {
            System.out.println("Error reading orders file: " + e.getMessage());
        }
    }

    public static void printOrdersBetweenDates(String startDate, String endDate) {
        System.out.println("Orders between " + startDate + " and " + endDate + ":");

        ordersTree.inOrderTraversal(order -> {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date orderDate = sdf.parse(order.getOrderDate());
                Date start = sdf.parse(startDate);
                Date end = sdf.parse(endDate);

                if (!orderDate.before(start) && !orderDate.after(end)) {
                    System.out.println("Order ID: " + order.getOrderId() +
                            ", Customer: " + order.getCustomer().getName() +
                            ", Date: " + order.getOrderDate() +
                            ", Total: " + order.getTotalPrice() + " SR" +
                            ", Status: " + order.getStatus());
                }
            } catch (ParseException e) {
                System.out.println("Error parsing date for order: " + order.getOrderId());
            }
        });
    }

    @Override
    public String toString() {
        return "Order ID: " + orderId + ", Customer: " + customer.getName() +
                ", Date: " + orderDate + ", Total: " + totalPrice + " SR, Status: " + status;
    }
}