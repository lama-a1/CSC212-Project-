/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212_project;

/**
 *
 * @author memem
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

public class Product {
    public static AVLTree<Product> productTree = new AVLTree<>();
    private static AVLTree<Product> productByNameTree = new AVLTree<>();

    private int productId;
    private String name;
    private double price;
    private int stock;
    private AVLTree<Review> reviewsTree;

    public Product(int productId, String name, double price, int stock) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.reviewsTree = new AVLTree<>();
    }

    public int getProductId() { return productId; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getStock() { return stock; }
    public AVLTree<Review> getReviewsTree() { return reviewsTree; }

    public void updateProduct(String name, double price, int stock) {
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    public void addReview(Review review) {
        String key = String.valueOf(review.getReviewId());
        reviewsTree.insert(key, review);
    }

    public void displayProduct(boolean showReviews) {
        System.out.println("*********************");
        System.out.println("Product ID: " + productId + ", Name: " + name +
                ", Price: " + price + " SR" + ", Stock: " + stock);

        if (showReviews) {
            if (reviewsTree.empty()) {
                System.out.println("   No reviews yet.");
            } else {
                System.out.println("*********************");
                System.out.println("   Reviews:");
                reviewsTree.inOrderTraversal(review -> review.display());
            }
        }
    }

    public double getAverageRating() {
        if (reviewsTree.empty()) return 0.0;

        final double[] total = {0};
        final int[] count = {0};

        reviewsTree.inOrderTraversal(review -> {
            total[0] += review.getRating();
            count[0]++;
        });

        return total[0] / count[0];
    }

    public void decreaseStock(int quantity) {
        if (this.stock >= quantity) {
            this.stock -= quantity;
        }
    }

    public void increaseStock(int quantity) {
        this.stock += quantity;
    }

    public boolean isOutOfStock() {
        return stock == 0;
    }

    @Override
    public String toString() {
        return "Product ID: " + productId + ", Name: " + name + ", Price: " + price + " SR, Stock: " + stock;
    }

    public static void addProduct(Product product) {
        String key = String.valueOf(product.getProductId());
        productTree.insert(key, product);
        productByNameTree.insert(product.getName().toLowerCase(), product);
    }

    public static Product searchById(int id) {
        return productTree.search(String.valueOf(id));
    }

    public static Product searchByName(String name) {
        return productByNameTree.search(name.toLowerCase());
    }

    public static boolean updateProduct(int productId, String name, double price, int stock) {
        Product p = searchById(productId);
        if (p == null) return false;

        p.updateProduct(name, price, stock);
        return true;
    }

    public static void loadProducts(String filePath) {
        try (Scanner scanner = new Scanner(new File(filePath))) {
            if (scanner.hasNextLine()) scanner.nextLine();

            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                if (data.length < 4) continue;

                int productId = Integer.parseInt(data[0]);
                String name = data[1];
                double price = Double.parseDouble(data[2]);
                int stock = Integer.parseInt(data[3]);

                Product product = new Product(productId, name, price, stock);
                addProduct(product);
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
        } catch (Exception e) {
            System.out.println("Error reading products file: " + e.getMessage());
        }
    }

    public static void displayAllProducts(boolean showReviews) {
        if (productTree.empty()) {
            System.out.println("No products available.");
            return;
        }

        productTree.inOrderTraversal(product -> {
            product.displayProduct(showReviews);
            if (product.isOutOfStock()) {
                System.out.println("----- Item is not available (Out of stock)! -----");
            }
        });
    }

    public static void displayAllProducts() {
        displayAllProducts(false);
    }

    public static AVLTree<Product> getOutOfStockProducts() {
        AVLTree<Product> outOfStockTree = new AVLTree<>();

        productTree.inOrderTraversal(product -> {
            if (product.isOutOfStock()) {
                outOfStockTree.insert(String.valueOf(product.getProductId()), product);
            }
        });

        return outOfStockTree;
    }

    public static void displayTop3RatedProducts() {
        List<Product> allProducts = productTree.getAllElements();

        if (allProducts.isEmpty()) {
            System.out.println("No products available.");
            return;
        }

        allProducts.sort((p1, p2) -> Double.compare(p2.getAverageRating(), p1.getAverageRating()));

        System.out.println("TOP 3 RATED PRODUCTS:");
        int count = Math.min(3, allProducts.size());
        for (int i = 0; i < count; i++) {
            Product p = allProducts.get(i);
            System.out.println((i + 1) + ". " + p.getName() + " | Rating: " +
                    String.format("%.2f", p.getAverageRating()) +
                    "/5 , Price: " + p.getPrice() + " SR");
        }
    }
}