/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc212project;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author waada
 */

public class Customers {
    
    private int customerId;
    private String name;
    private String email;
    private LinkedList<Orders> orders;

    private static LinkedList<Customers> customersList = new LinkedList<>();
    
    public Customers(int customerId, String name, String email) {
        this.customerId = customerId;
        this.name = name;
        this.email = email;
        this.orders = new LinkedList<>();
    }

    //  Register new customer 
    public static Customers registerNewCustomer(int id, String name, String email) {
        if (customersList.full()) {
            System.out.println("Cannot register new customer. Customers list is full!");
            return null;
        }
        Customers c = new Customers(id, name, email);
        if (customersList.empty()) {
            customersList.insert(c);
        } else {
            customersList.findFirst();
            while (!customersList.last()) customersList.findNext();
            customersList.insert(c);
        }
        System.out.println("Customer registered: " + name + " (ID: " + id + ")");
        return c;
    }

    // find customer by id 
    public static Customers findCustomerById(int id) {
        if (customersList.empty()) return null;

        customersList.findFirst();
        while (true) {
            Customers c = customersList.retrieve();
            if (c != null && c.getCustomerId() == id) {
                return c;
            }
            if (customersList.last()) break;
            customersList.findNext();
        }
        return null;
    }

    // View order history  for specific customer 
    public static void viewOrderHistoryForCustomer(int customerId) {
        Customers c = findCustomerById(customerId);
        if (c == null) {
            System.out.println("Customer with ID " + customerId + " not found.");
            return;
        }
        c.viewOrderHistory();
    }

    // Load customers from CSV
    public static void loadCustomers(String filePath) {
        File file = new File(filePath);
        int count = 0;

        try (Scanner sc = new Scanner(file)) {
            if (sc.hasNextLine()) sc.nextLine(); 

            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split(",", 3);
                if (parts.length < 3) continue;

                int id;
                try {
                    id = Integer.parseInt(parts[0].trim());
                } catch (NumberFormatException e) {
                    continue;
                }

                String name  = parts[1].trim();
                String email = parts[2].trim();

                if (findCustomerById(id) != null) continue;

                Customers c = new Customers(id, name, email);

                if (customersList.empty()) customersList.insert(c);
                else {
                    customersList.findFirst();
                    while (!customersList.last()) customersList.findNext();
                    customersList.insert(c);
                }
                count++;
            }
          
        } catch (FileNotFoundException e) {
            System.out.println("Customers file not found: " + filePath);
        } catch (Exception e) {
            System.out.println("Error reading customers file: " + e.getMessage());
        }
    }

    // place a new order for THIS customer
    public void placeOrder(Orders newOrder) {
        if (newOrder == null) {
            System.out.println("Cannot place a null order.");
            return;
        }
        if (newOrder.getCustomer() != this) {
            newOrder.setCustomer(this);
        }

        if (orders.full()) {
            System.out.println("Cannot place order. Orders list is full!");
            return;
        }

        if (orders.empty()) orders.insert(newOrder);
        else {
            orders.findFirst();
            while (!orders.last()) orders.findNext();
            orders.insert(newOrder);
        }

        System.out.println("Order placed successfully for " + name +
                           " (Order ID: " + newOrder.getOrderId() + ")");
    }

    // view THIS customer's order history
    public void viewOrderHistory() {
        if (orders.empty()) {
            System.out.println(name + " has no orders yet.");
            return;
        }
        System.out.println("Order history for " + name + ":");
        orders.findFirst();
        while (true) {
            Orders o = orders.retrieve();
            if (o != null) {
                System.out.println("- Order ID: " + o.getOrderId() +
                                   ", Status: " + o.getStatus() +
                                   ", Total: " + o.getTotalPrice());
            }
            if (orders.last()) break;
            orders.findNext();
        }
    }

    public int getCustomerId() { return customerId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public LinkedList<Orders> getOrders() { return orders; }

    public static LinkedList<Customers> getCustomersList() {
        return customersList;
    }
}
